/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;

import org.eclipse.stardust.common.CompareHelper;
import org.eclipse.stardust.common.error.LoginFailedException;
import org.eclipse.stardust.engine.core.spi.security.LoginProvider;
import org.eclipse.stardust.engine.core.spi.security.LoginResult;

/**
 * @author ubirkemeyer
 * @version $Revision$
 */
public class PropertyFileLoginService implements LoginProvider
{
   public LoginResult login(String id, String password)
   {
      PropertyRegistry registry = new PropertyRegistry();
      registry.load();
      boolean success = CompareHelper.areEqual(registry.getPassword(id), password);
      if (success)
      {
         return LoginResult.testifySuccess();
      }
      else
      {
         return LoginResult.testifyFailure(new LoginFailedException("Invalid user '" + id
               + "', or password was incorrect.", LoginFailedException.INVALID_PASSWORD));
      }
   }
}
