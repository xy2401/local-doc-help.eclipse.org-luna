********************************************

Web Services Java Client Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

This directory contains the source code for two example implementations of a 
Java Web Service client that communicate with a deployed product 
engine which provides Web Services:
 
 * org.eclipse.stardust.examples.wsclient.WsClientExampleApp 
      - This example demonstrates running a tiny process
        using the Web Services API. Please note that a deployed
        model WsClientExampleModel.xpdl, which is shipped with this
        example as well, is necessary to run this sample application.
 * org.eclipse.stardust.examples.wsclient.WsClientAuthExampleApp 
      - This example demonstrates all permitted
        authentication mechanisms.

In order to build a custom WS Client the factory 
org.eclipse.stardust.examples.wsclient.WsFactory may be used to easily gain a
reference to an exposed Web Service. To run the examples the
properties file product-ws.properties has to be put in the classpath and is bound to
contain the properties (host, port and context root) of the actual running
Web Service. 
