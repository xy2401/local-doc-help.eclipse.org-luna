/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
'use strict'
var newRESTClient = angular.module('newRESTClient', ['ngResource']);
function disputeCtrl($scope, $resource, $window){
 
	$scope.$window = $window;
 
	$scope.Dispute ={};
	var x2j = new X2JS();
	/* This method seraches and returns the desired query parameter (passed as arg) out of 
	window.location.href, which contains entire URL like:
	http://localhost:8000/app/firstExample.html?
	ippInteractionUri=http://localhost:9090/AXISDemo/services/rest/engine/interactions/MTA1fDEzNzU5NDIzNTE4ODY=
	&ippPortalBaseUri=http://localhost:9090/AXISDemo
	&ippServicesBaseUri=http://localhost:9090/AXISDemo/services/ */
	$scope.urlParam = function(name){
	    var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(window.location.href);
	    if (!results)
	    { 
	        return 0; 
	    }
	    return results[1] || 0;
	}
 
	$scope.saveDispute = function(){
	    var disputeData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Dispute1>"+x2j.json2xml_str($scope.Dispute)+"
		</Dispute1>";
	    console.debug("Dispute to Submit: "+ disputeData);
	    var res1 = $resource($scope.callbackURL+'/outData/Dispute2', {params: '@disputeData'}, {'put': {method: 
  		'PUT',  isArray: false, headers:{'Content-Type':'application/xml; charset=UTF-8'}}});
  		res1.put(disputeData, 
  		function success() {console.debug("Success");}, function error() {console.debug("Failure");});
  		$scope.sleep(3000);
  		//*****Ensures that on button click IPP's activity that contains this UI gets completed and closed****
		var mainIppFrame = parent;
			    //alert(mainIppFrame);
 
			    if (mainIppFrame)
			    {
			      if (mainIppFrame.InfinityBpm)
			      {
			 		mainIppFrame.InfinityBpm.ProcessPortal.completeActivity();
 
			      }
			    }
	}
	/**
	* Delay for a number of milliseconds
	*/
	$scope.sleep = function (delay)
	{
	    var start = new Date().getTime();
	    while (new Date().getTime() < start + delay);
	}
 
 
	$scope.sleep(1000);
 
	$scope.callbackURL = $scope.urlParam("ippInteractionUri");
		//To ensure that $resource maintains port no.
		if($scope.callbackURL){
		var newTemp = $scope.callbackURL.replace(/:/g, "\\:");
	}
		$scope.callbackURL = newTemp;
 
		/*This section of scripts fetches data from IPP and set it to $scope data*/
		var res2 = $resource($scope.callbackURL+'/inData/Dispute1', {}, {'get': {method: 
  		'GET', transformResponse: function(data) {
  			console.debug("Data is:" + data);
		var json = x2js.xml_str2json(data );
		console.debug("JSON Data is:" + json.Dispute.disputeID);
		$scope.Dispute.disputeID = json.Dispute.disputeID;
		$scope.Dispute.description = json.Dispute.description;		
		}, isArray: false}});
  		res2.get(function success(data) {console.debug("Success");}, function error() {console.debug("Failure");});
 }