********************************************

Configuration Variables Examples

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The example provided in this section demonstrates the usage of
configuration variables. It contains the example model used in the 
tutorial.

Please find the according tutorial in the Tutorial Guide of the documentation:

 * Using a Configuration Variable to Control a Process Flow
      - a simple use case example on how to use a configuration variable to control a
        process workflow.
