﻿using System;
using System.Collections.Generic;
using com.infinity.bpm.api;
using com.infinity.bpm.api.query.stubs;
using System.Text;
using System.Xml;

namespace InfinityWsClient
{
    /// <summary>
    ///  This sample demonstrates running a tiny process using the WS API. It depends on the
    ///  process model <code>WsClientExampleModel.xpdl</code> and comprises the following
    ///  steps
    ///  
    ///   * Starting a process with a process attachment
    ///   * Accessing the process attachment
    ///   * Querying for process instances
    ///   * Querying for activity instances
    ///   * Adding a grant to the session user
    ///   * Completing the activity which finishes the process
    /// </summary>
    class WsClientExampleApp
    {
        private const String MOTU_USERNAME = "motu";
        private const String MOTU_PWD = "motu";
        private static readonly Dictionary<String, String> SESSION_PROPERTIES;

        private const String PROCESS_DEFINITION_NAME = "ProcessDefinition";
        private const String PROCESS_ATTACHMENTS_ID = "PROCESS_ATTACHMENTS";
        private const String ROLE_ID = "Role";

        private static readonly IWorkflowService wfService;
        private static readonly IQueryService queryService;
        private static readonly IUserService userService;

        static WsClientExampleApp()
        {
            SESSION_PROPERTIES = InitSessionProperties();

            wfService = WsFactory.GetWorkflowService(MOTU_USERNAME, MOTU_PWD, 
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);
            queryService = WsFactory.GetQueryService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);
            userService = WsFactory.GetUserService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);
        }

        static void Main(String[] args)
        {
            ProcessInstance pi = StartProcess();
            AccessProcessAttachment(pi);
            DoPiQuery();
            DoAiQuery();
            AddGrantToSessionUser(pi.modelOid);
            CompleteAI(pi);
        }

        private static ProcessInstance StartProcess()
        {
            Console.Out.WriteLine("-- Starting a process with a process attachment --");
            InputDocuments processAttachment = CreateProcessAttachments();
            ProcessInstance pi = wfService.startProcess(PROCESS_DEFINITION_NAME, null, true, processAttachment);
            Console.Out.WriteLine("Process '{0}' started with Process Instance OID {1}.", PROCESS_DEFINITION_NAME, pi.oid);
            return pi;
        }

        private static void AccessProcessAttachment(ProcessInstance pi)
        {
            Console.Out.WriteLine("-- Accessing the process attachment --");
            propertyIds propertyIds = new propertyIds();
            propertyIds.Add(PROCESS_ATTACHMENTS_ID);
            InstanceProperties properties = wfService.getProcessProperties(pi.oid, propertyIds);
            foreach (Parameter p in properties)
            {
                if (p.name == PROCESS_ATTACHMENTS_ID)
                {
                    Console.Out.WriteLine("Process Attachment:");
                    XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                    xmlWriterSettings.Indent = true;
                    XmlWriter xmlWriter = XmlWriter.Create(Console.Out, xmlWriterSettings);
                    p.xml.WriteXml(xmlWriter);
                    xmlWriter.Flush();
                    Console.Out.WriteLine("");
                }
            }
        }

        private static void DoPiQuery()
        {
            Console.Out.WriteLine("-- Querying for process instances --");
            ProcessInstanceQueryResult piqr = queryService.findProcesses(new ProcessQuery());
            foreach (ProcessInstance p in piqr.processInstances)
            {
                Console.Out.WriteLine("Process Instance with OID {0} found, state is {1}.", p.oid, p.state);
            }
        }

        private static void DoAiQuery()
        {
            Console.Out.WriteLine("-- Querying for activity instances --");
            ActivityQueryResult aqr = queryService.findActivities(new ActivityQuery());
            foreach (ActivityInstance a in aqr.activityInstances)
            {
                Console.Out.WriteLine("Activity Instance with OID {0} found, state is {1}.", a.oid, a.state);
            }
        }

        private static void AddGrantToSessionUser(int modelOid)
        {
            Console.Out.WriteLine("-- Adding a grant to the session user --");
            User user = wfService.getSessionUser();
            grant grant = new grant();
            grant.modelOid = modelOid;
            grant.id = ROLE_ID;
            user.grants.Add(grant);
            userService.modifyUser(user, false);
        }

        private static void CompleteAI(ProcessInstance pi)
        {
            Console.Out.WriteLine("-- Completing the activity which finishes the process --");
            ActivityInstance ai = wfService.activateNextActivityForProcess(pi.oid);
            ai = wfService.completeActivity(ai.processOid, null, null, false);
            Console.Out.WriteLine("State of Activity Instance with OID {0} after Completion: {1}.", ai.oid, ai.state);
        }

        private static InputDocuments CreateProcessAttachments()
        {
            InputDocuments inputDocs = new InputDocuments();
            InputDocument inputDoc = new InputDocument();
            inputDoc.documentInfo = CreateDocInfo();
            inputDoc.content = CreateContent();
            inputDoc.targetFolder = "/Test-" + DateTime.Now.Ticks;
            inputDocs.Add(inputDoc);
            return inputDocs;
        }

        private static DocumentInfo CreateDocInfo()
        {
            DocumentInfo docInfo = new DocumentInfo();
            docInfo.name = "SampleDoc.txt";
            docInfo.description = "This is a sample document.";
            docInfo.contentType = "text/plain";
            return docInfo;
        }

        private static byte[] CreateContent()
        {
            return new UTF8Encoding().GetBytes("This is a sample document.");
        }

        private static Dictionary<String, String> InitSessionProperties()
        {
            Dictionary<String, String> sessionProperties = new Dictionary<String, String>();
            sessionProperties.Add(WsFactory.SESSION_PROP_PARTITION, "default");
            sessionProperties.Add(WsFactory.SESSION_PROP_REALM, "carnot");
            sessionProperties.Add(WsFactory.SESSION_PROP_DOMAIN, "default");
            return sessionProperties;
        }
    }
}