﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;
using System.Text;
using com.infinity.bpm.api;
using System.Configuration;
using System.Collections;

namespace InfinityWsClient
{
    public class WsFactory
    {
        public const String SESSION_PROP_PARTITION = "Security.Partition";
        public const String SESSION_PROP_REALM = "Security.Realm";
        public const String SESSION_PROP_DOMAIN = "Security.Domain";

        private const String PRODUCT_NS = "http://infinity.com/bpm/ws/v2009a/api";

        private const String URL_HTTP_BASIC_AUTH_SUFFIX = "HttpBasicAuth";
        private const String URL_HTTP_BASIC_AUTH_SSL_SUFFIX = "HttpBasicAuthSsl";
        private const String URL_WSS_USERNAME_TOKEN_SUFFIX = "WssUsernameToken";

        private const String REF_PARAM_PARTITION = "infinity-bpm-partition";
        private const String REF_PARAM_REALM = "infinity-bpm-realm";
        private const String REF_PARAM_DOMAIN = "infinity-bpm-domain";

        private const String WF_SERVICE = "WorkflowService";
        private const String QUERY_SERVICE = "QueryService";
        private const String DOC_MGMT_SERVICE = "DocumentManagementService";
        private const String USER_SERVICE = "UserService";
        private const String ADMIN_SERVICE = "AdministrationService";

        private const String WEB_SERVICE_HOST = "Host";
        private const String WEB_SERVICE_SSL_PORT = "SslPort";
        private const String WEB_SERVICE_PORT = "Port";
        private const String WEB_SERVICE_CONTEXT_ROOT = "ContextRoot";

        public static readonly String WF_SERVICE_HTTP_BASIC_AUTH;
        public static readonly String WF_SERVICE_HTTP_BASIC_AUTH_SSL;
        public static readonly String WF_SERVICE_WSS_USERNAME_TOKEN;

        public static readonly String QUERY_SERVICE_HTTP_BASIC_AUTH;
        public static readonly String QUERY_SERVICE_HTTP_BASIC_AUTH_SSL;
        public static readonly String QUERY_SERVICE_WSS_USERNAME_TOKEN;

        public static readonly String DOC_MGMT_SERVICE_HTTP_BASIC_AUTH;
        public static readonly String DOC_MGMT_SERVICE_HTTP_BASIC_AUTH_SSL;
        public static readonly String DOC_MGMT_WSS_USERNAME_TOKEN;

        public static readonly String USER_SERVICE_HTTP_BASIC_AUTH;
        public static readonly String USER_SERVICE_HTTP_BASIC_AUTH_SSL;
        public static readonly String USER_SERVICE_WSS_USERNAME_TOKEN;

        public static readonly String ADMIN_SERVICE_HTTP_BASIC_AUTH;
        public static readonly String ADMIN_SERVICE_HTTP_BASIC_AUTH_SSL;
        public static readonly String ADMIN_SERVICE_WSS_USERNAME_TOKEN;

        private static readonly String URL_PREFIX;
        private static readonly String URL_SSL_PREFIX;
        private static readonly Dictionary<ServiceAuthModePair, String> SERVICE_URL_DICT;
        private static readonly Dictionary<String, String> SESSION_PROPERTY_2_REF_PARAM;

        static WsFactory()
        {
            String[] urls = ResolveUrlPrefix();
            URL_SSL_PREFIX = urls[0];
            URL_PREFIX = urls[1];

            WF_SERVICE_HTTP_BASIC_AUTH = URL_PREFIX + WF_SERVICE + URL_HTTP_BASIC_AUTH_SUFFIX;
            WF_SERVICE_HTTP_BASIC_AUTH_SSL = URL_SSL_PREFIX + WF_SERVICE + URL_HTTP_BASIC_AUTH_SSL_SUFFIX;
            WF_SERVICE_WSS_USERNAME_TOKEN = URL_SSL_PREFIX + WF_SERVICE + URL_WSS_USERNAME_TOKEN_SUFFIX;

            QUERY_SERVICE_HTTP_BASIC_AUTH = URL_PREFIX + QUERY_SERVICE + URL_HTTP_BASIC_AUTH_SUFFIX;
            QUERY_SERVICE_HTTP_BASIC_AUTH_SSL = URL_SSL_PREFIX + QUERY_SERVICE + URL_HTTP_BASIC_AUTH_SSL_SUFFIX;
            QUERY_SERVICE_WSS_USERNAME_TOKEN = URL_SSL_PREFIX + QUERY_SERVICE + URL_WSS_USERNAME_TOKEN_SUFFIX;
            
            DOC_MGMT_SERVICE_HTTP_BASIC_AUTH = URL_PREFIX + DOC_MGMT_SERVICE + URL_HTTP_BASIC_AUTH_SUFFIX;
            DOC_MGMT_SERVICE_HTTP_BASIC_AUTH_SSL = URL_SSL_PREFIX + DOC_MGMT_SERVICE + URL_HTTP_BASIC_AUTH_SSL_SUFFIX;
            DOC_MGMT_WSS_USERNAME_TOKEN = URL_SSL_PREFIX + DOC_MGMT_SERVICE + URL_WSS_USERNAME_TOKEN_SUFFIX;
            
            USER_SERVICE_HTTP_BASIC_AUTH = URL_PREFIX + USER_SERVICE + URL_HTTP_BASIC_AUTH_SUFFIX;
            USER_SERVICE_HTTP_BASIC_AUTH_SSL = URL_SSL_PREFIX + USER_SERVICE + URL_HTTP_BASIC_AUTH_SSL_SUFFIX;
            USER_SERVICE_WSS_USERNAME_TOKEN = URL_SSL_PREFIX + USER_SERVICE + URL_WSS_USERNAME_TOKEN_SUFFIX;
            
            ADMIN_SERVICE_HTTP_BASIC_AUTH = URL_PREFIX + ADMIN_SERVICE + URL_HTTP_BASIC_AUTH_SUFFIX;
            ADMIN_SERVICE_HTTP_BASIC_AUTH_SSL = URL_SSL_PREFIX + ADMIN_SERVICE + URL_HTTP_BASIC_AUTH_SSL_SUFFIX;
            ADMIN_SERVICE_WSS_USERNAME_TOKEN = URL_SSL_PREFIX + ADMIN_SERVICE + URL_WSS_USERNAME_TOKEN_SUFFIX;

            SERVICE_URL_DICT = CreateServiceUrlDict();
            SESSION_PROPERTY_2_REF_PARAM = InitSessionProperty2RefParamDict();
        }

        public static IWorkflowService GetWorkflowService(String username, String password,
            Dictionary<String, String> sessionProperties, AuthenticationMode authMode)
        {
            return GetServiceClient<WorkflowServiceClient, IWorkflowService>(username, password, sessionProperties, authMode);
        }

        public static IQueryService GetQueryService(String username, String password,
            Dictionary<String, String> sessionProperties, AuthenticationMode authMode)
        {
            return GetServiceClient<QueryServiceClient, IQueryService>(username, password, sessionProperties, authMode);
        }

        public static IDocumentManagementService GetDocMgmtService(String username, String password,
            Dictionary<String, String> sessionProperties, AuthenticationMode authMode)
        {
            return GetServiceClient<DocumentManagementServiceClient, IDocumentManagementService>(username, password, sessionProperties, authMode);
        }

        public static IUserService GetUserService(String username, String password,
            Dictionary<String, String> sessionProperties, AuthenticationMode authMode)
        {
            return GetServiceClient<UserServiceClient, IUserService>(username, password, sessionProperties, authMode);
        }

        public static IAdministrationService GetAdminService(String username, String password,
            Dictionary<String, String> sessionProperties, AuthenticationMode authMode)
        {
            return GetServiceClient<AdministrationServiceClient, IAdministrationService>(username, password, sessionProperties, authMode);
        }

        private static T GetServiceClient<T, U>(String username, String password,
            Dictionary<String, String> sessionProperties, AuthenticationMode authMode)
            where T : ClientBase<U>
            where U : class
        {
            Binding binding;
            if (authMode == AuthenticationMode.HttpBasicAuthentication)
            {
                binding = CreateBasicHttpBinding();
            }
            else if (authMode == AuthenticationMode.HttpBasicAuthenticationSsl)
            {
                binding = CreateBasicHttpsBinding();
            }
            else if (authMode == AuthenticationMode.WssUsernameToken)
            {
                binding = CreateWssUsernameTokenBinding();
            }
            else
            {
                throw new NotSupportedException(
                    "Authentication mode has to be one of '"
                    + AuthenticationMode.HttpBasicAuthentication + "', '"
                    + AuthenticationMode.HttpBasicAuthenticationSsl
                    + "','" + AuthenticationMode.WssUsernameToken
                    + "'.");
            }

            ServiceAuthModePair pair = new ServiceAuthModePair(typeof(T), authMode);
            EndpointAddress ea = new EndpointAddress(new Uri(SERVICE_URL_DICT[pair]), AddSessionProperties(sessionProperties));

            T serviceClient = CreateServiceClient<T, U>(username, password, binding, ea);

            return serviceClient;
        }

        private static Binding CreateBasicHttpBinding()
        {
            HttpTransportBindingElement transport = new HttpTransportBindingElement();
            transport.AuthenticationScheme = AuthenticationSchemes.Basic;
            return CreateBasicHttpBinding(transport);
        }

        private static Binding CreateBasicHttpsBinding()
        {
            HttpsTransportBindingElement transport = CreateHttpsTransportBindingElement();
            transport.AuthenticationScheme = AuthenticationSchemes.Basic;
            return CreateBasicHttpBinding(transport);
        }

        private static Binding CreateBasicHttpBinding(BindingElement transport)
        {
            BindingElement encoding = CreateTextMessageEncodingBindingElement();
            BindingElement[] bindingElements = { encoding, transport };
            return new CustomBinding(bindingElements);
        }

        private static Binding CreateWssUsernameTokenBinding()
        {
            BindingElement transport = CreateHttpsTransportBindingElement();
            BindingElement encoding = CreateTextMessageEncodingBindingElement();
            BindingElement security = CreateTransportSecurityBindingElement();
            BindingElement[] bindings = { security, encoding, transport };
            return new CustomBinding(bindings);
        }

        private static AddressHeader[] AddSessionProperties(Dictionary<String, String> sessionProperties)
        {
            List<AddressHeader> addressHeaders = new List<AddressHeader>();
            foreach (String sessionProp in sessionProperties.Keys)
            {
                String refParamName = SESSION_PROPERTY_2_REF_PARAM[sessionProp];
                if (refParamName != null)
                {
                    addressHeaders.Add(AddressHeader.CreateAddressHeader(refParamName, PRODUCT_NS, sessionProperties[sessionProp]));
                }
                else
                {
                    // TODO log warning
                }
            }
            return addressHeaders.ToArray();
        }

        private static T CreateServiceClient<T, U>(String username, String password, Binding binding, EndpointAddress ea)
            where T : ClientBase<U>
            where U : class
        {
            Type[] ctorParamTypes = { typeof(Binding), typeof(EndpointAddress) };
            ConstructorInfo ctorInfo = typeof(T).GetConstructor(ctorParamTypes);

            Object[] ctorParams = { binding, ea };
            T client = (T)ctorInfo.Invoke(ctorParams);

            client.ChannelFactory.Credentials.UserName.UserName = username;
            client.ChannelFactory.Credentials.UserName.Password = password;

            return client;
        }

        private static HttpsTransportBindingElement CreateHttpsTransportBindingElement()
        {
            HttpsTransportBindingElement transport = new HttpsTransportBindingElement();
            transport.ManualAddressing = false;
            transport.MaxBufferPoolSize = 524288;
            transport.MaxReceivedMessageSize = 65536;
            transport.AllowCookies = false;
            transport.AuthenticationScheme = AuthenticationSchemes.Anonymous;
            transport.BypassProxyOnLocal = false;
            transport.HostNameComparisonMode = HostNameComparisonMode.StrongWildcard;
            transport.KeepAliveEnabled = true;
            transport.MaxBufferSize = 65536;
            transport.ProxyAuthenticationScheme = AuthenticationSchemes.Anonymous;
            transport.Realm = "";
            transport.TransferMode = TransferMode.Buffered;
            transport.UnsafeConnectionNtlmAuthentication = false;
            transport.UseDefaultWebProxy = true;
            transport.RequireClientCertificate = false;
            return transport;
        }

        private static TextMessageEncodingBindingElement CreateTextMessageEncodingBindingElement()
        {
            TextMessageEncodingBindingElement encoding = new TextMessageEncodingBindingElement();
            encoding.MaxReadPoolSize = 64;
            encoding.MaxWritePoolSize = 16;
            encoding.MessageVersion = MessageVersion.Soap11WSAddressing10;
            encoding.WriteEncoding = Encoding.UTF8;
            encoding.ReaderQuotas.MaxDepth = 32;
            encoding.ReaderQuotas.MaxStringContentLength = 8192;
            encoding.ReaderQuotas.MaxArrayLength = 16384;
            encoding.ReaderQuotas.MaxBytesPerRead = 4096;
            encoding.ReaderQuotas.MaxNameTableCharCount = 16384;
            return encoding;
        }

        private static TransportSecurityBindingElement CreateTransportSecurityBindingElement()
        {
            TransportSecurityBindingElement security = TransportSecurityBindingElement.CreateUserNameOverTransportBindingElement();
            security.DefaultAlgorithmSuite = SecurityAlgorithmSuite.Basic128;
            security.SetKeyDerivation(true);
            security.SecurityHeaderLayout = SecurityHeaderLayout.Lax;
            security.IncludeTimestamp = true;
            security.KeyEntropyMode = SecurityKeyEntropyMode.CombinedEntropy;
            security.MessageSecurityVersion = MessageSecurityVersion.Default;
            return security;
        }

        private static String[] ResolveUrlPrefix()
        {
            Hashtable properties = (Hashtable) ConfigurationManager.GetSection("wsSection");

            String host = (String) properties[WEB_SERVICE_HOST];
            String sslPort = (String)properties[WEB_SERVICE_SSL_PORT];
            String port = (String) properties[WEB_SERVICE_PORT];
            String contextRoot = (String) properties[WEB_SERVICE_CONTEXT_ROOT];

            if (host == null || host.Length == 0 || sslPort == null || sslPort.Length == 0 || contextRoot == null || contextRoot.Length == 0)
            {
                throw new Exception("Missing Application Configuration for Web Service.");
            }

            return new String[] {"https://" + host + ":" + sslPort + "/" + contextRoot + "/services/soap/",
                                 "http://" + host + ":" + port + "/" + contextRoot + "/services/soap/"};
        }

        private static Dictionary<ServiceAuthModePair, String> CreateServiceUrlDict()
        {
            Dictionary<ServiceAuthModePair, String> serviceUrlDict = new Dictionary<ServiceAuthModePair, String>();

            serviceUrlDict.Add(new ServiceAuthModePair(typeof(WorkflowServiceClient), AuthenticationMode.HttpBasicAuthentication),
                WF_SERVICE_HTTP_BASIC_AUTH);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(WorkflowServiceClient), AuthenticationMode.HttpBasicAuthenticationSsl),
                WF_SERVICE_HTTP_BASIC_AUTH_SSL);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(WorkflowServiceClient), AuthenticationMode.WssUsernameToken),
                WF_SERVICE_WSS_USERNAME_TOKEN);

            serviceUrlDict.Add(new ServiceAuthModePair(typeof(QueryServiceClient), AuthenticationMode.HttpBasicAuthentication),
                QUERY_SERVICE_HTTP_BASIC_AUTH);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(QueryServiceClient), AuthenticationMode.HttpBasicAuthenticationSsl),
                QUERY_SERVICE_HTTP_BASIC_AUTH_SSL);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(QueryServiceClient), AuthenticationMode.WssUsernameToken),
                QUERY_SERVICE_WSS_USERNAME_TOKEN);

            serviceUrlDict.Add(new ServiceAuthModePair(typeof(DocumentManagementServiceClient), AuthenticationMode.HttpBasicAuthentication),
                DOC_MGMT_SERVICE_HTTP_BASIC_AUTH);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(DocumentManagementServiceClient), AuthenticationMode.HttpBasicAuthenticationSsl),
                DOC_MGMT_SERVICE_HTTP_BASIC_AUTH_SSL);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(DocumentManagementServiceClient), AuthenticationMode.WssUsernameToken),
                DOC_MGMT_WSS_USERNAME_TOKEN);

            serviceUrlDict.Add(new ServiceAuthModePair(typeof(UserServiceClient), AuthenticationMode.HttpBasicAuthentication),
                USER_SERVICE_HTTP_BASIC_AUTH);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(UserServiceClient), AuthenticationMode.HttpBasicAuthenticationSsl),
                USER_SERVICE_HTTP_BASIC_AUTH_SSL);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(UserServiceClient), AuthenticationMode.WssUsernameToken),
                USER_SERVICE_WSS_USERNAME_TOKEN);

            serviceUrlDict.Add(new ServiceAuthModePair(typeof(AdministrationServiceClient), AuthenticationMode.HttpBasicAuthentication),
                ADMIN_SERVICE_HTTP_BASIC_AUTH);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(AdministrationServiceClient), AuthenticationMode.HttpBasicAuthenticationSsl),
                ADMIN_SERVICE_HTTP_BASIC_AUTH_SSL);
            serviceUrlDict.Add(new ServiceAuthModePair(typeof(AdministrationServiceClient), AuthenticationMode.WssUsernameToken),
                ADMIN_SERVICE_WSS_USERNAME_TOKEN);

            return serviceUrlDict;
        }

        private static Dictionary<String, String> InitSessionProperty2RefParamDict()
        {
            Dictionary<String, String> dict = new Dictionary<String, String>();
            dict.Add(SESSION_PROP_PARTITION, REF_PARAM_PARTITION);
            dict.Add(SESSION_PROP_REALM, REF_PARAM_REALM);
            dict.Add(SESSION_PROP_DOMAIN, REF_PARAM_DOMAIN);
            return dict;
        }

        public enum AuthenticationMode { HttpBasicAuthentication, HttpBasicAuthenticationSsl, WssUsernameToken }

        class ServiceAuthModePair
        {
            private readonly Type serviceClass;
            private readonly AuthenticationMode authMode;

            public ServiceAuthModePair(Type serviceClass, AuthenticationMode authMode)
            {
                if (serviceClass == null)
                {
                    throw new NullReferenceException("Service class must not be null.");
                }

                this.serviceClass = serviceClass;
                this.authMode = authMode;
            }

            public Type ServiceClass
            {
                get { return serviceClass; }
            }

            public AuthenticationMode AuthMode
            {
                get { return authMode; }
            }

            public override bool Equals(object obj)
            {
                if (obj == null || obj.GetType() != this.GetType())
                {
                    return false;
                }

                ServiceAuthModePair that = (ServiceAuthModePair)obj;
                return this.serviceClass.Equals(that.serviceClass)
                    && this.authMode.Equals(that.authMode);
            }

            public override int GetHashCode()
            {
                return serviceClass.GetHashCode() + authMode.GetHashCode();
            }
        }
    }
}
