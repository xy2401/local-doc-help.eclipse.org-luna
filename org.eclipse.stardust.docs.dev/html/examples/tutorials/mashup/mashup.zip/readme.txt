********************************************

UI Mashup Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The example model and sources provided in this section demonstrate
how to mash up angular based UI into our product Portal.

Tutorial

Please find the according tutorial in the Tutorial Guide of the documentation:

 * Mashing up Angular based UI into the product Portal
      - demonstrates how to mash up angular based UI into our product Portal
