/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000-2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.ldap;

import java.util.HashMap;

/**
 *
 * @author swoelk
 */
public class LDAPPerson
{
   private boolean existing = false;
   
   private String rdn = null;

   private String firstName = null;
   private String lastName = null;
   private String eMail = null;
   private String description = null;
   private HashMap<String, String> userProperties = null;
   
   public LDAPPerson()
   {
      userProperties = new HashMap<String, String>();
   }
   
   public boolean isExisting()
   {
      return existing;
   }

   public void setExisting(boolean existing)
   {
      this.existing = existing;
   }

   public String getFirstName()
   {
      return firstName;
   }

   public void setFirstName(String firstName)
   {
      this.firstName = firstName;
   }

   public String getLastName()
   {
      return lastName;
   }

   public void setLastName(String lastName)
   {
      this.lastName = lastName;
   }
 
   public String getEMail()
   {
      return eMail;
   }

   public void setEMail(String eMail)
   {
      this.eMail = eMail;
   }

   public String getDescription()
   {
      return description;
   }

   public void setDescription(String description)
   {
      this.description = description;
   }

   public String getUserProperty(String name)
   {
      return (String)userProperties.get(name);
   }

   public void setUserProperty(String name, String value)
   {
      userProperties.put(name, value);
   }

   public HashMap<String, String> getPropertyMap()
   {
      return userProperties;
   }

   public String getRdn() 
   {
      return rdn;
   }

   public void setRdn(String rdn) 
   {
      this.rdn = rdn;
   }
}
