/*******************************************************************************
 * Copyright (c) 2000, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/

package org.eclipse.stardust.examples.wsclient;

import static org.eclipse.stardust.examples.wsclient.WsFactory.getAdministrationService;
import static org.eclipse.stardust.examples.wsclient.WsFactory.getDocumentManagementService;
import static org.eclipse.stardust.examples.wsclient.WsFactory.getQueryService;
import static org.eclipse.stardust.examples.wsclient.WsFactory.getUserService;
import static org.eclipse.stardust.examples.wsclient.WsFactory.getWorkflowService;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.stardust.common.CollectionUtils;
import org.eclipse.stardust.engine.core.runtime.beans.removethis.SecurityProperties;
import org.eclipse.stardust.engine.api.ws.*;
import org.eclipse.stardust.engine.api.ws.PermissionsXto.PermissionXto;
import org.eclipse.stardust.examples.wsclient.WsFactory.AuthMode;

/**
 * @author nicolas.werlein
 * @version $Revision: $
 */
public class WsClientAuthExampleApp
{
   private static final String MOTU_USERNAME = "motu";

   private static final String MOTU_PWD = "motu";

   private static final Map<String, String> SESSION_PROPERTIES;

   static
   {
      SESSION_PROPERTIES = initSessionProperties();
   }

   public static void main(String[] args) throws BpmFault
   {
      doWorkflowServiceRequest();
      doQueryServiceRequest();
      doDocMgmtServiceRequest();
      doUserServiceRequest();
      doAdminServiceRequest();
   }

   private static void doWorkflowServiceRequest() throws BpmFault
   {
      System.out.print("Workflow Service:\n-----------------\n");
      IWorkflowService wfService;
      wfService = getWorkflowService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.HTTP_BASIC_AUTH);
      doWfServiceRequestAndPrint(wfService);
      wfService = getWorkflowService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.HTTP_BASIC_AUTH_SSL);
      doWfServiceRequestAndPrint(wfService);
      wfService = getWorkflowService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.WSS_USERNAME_TOKEN);
      doWfServiceRequestAndPrint(wfService);
   }

   private static void doQueryServiceRequest() throws BpmFault
   {
      System.out.print("\n\nQuery Service:\n--------------\n");
      IQueryService queryService;
      queryService = getQueryService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.HTTP_BASIC_AUTH);
      doQueryServiceRequestAndPrint(queryService);
      queryService = getQueryService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.HTTP_BASIC_AUTH_SSL);
      doQueryServiceRequestAndPrint(queryService);
      queryService = getQueryService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.WSS_USERNAME_TOKEN);
      doQueryServiceRequestAndPrint(queryService);
   }

   private static void doDocMgmtServiceRequest() throws BpmFault
   {
      System.out.print("\n\nDocument Management Service:\n----------------------------\n");
      IDocumentManagementService docMgmtService;
      docMgmtService = getDocumentManagementService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.HTTP_BASIC_AUTH);
      doDocMgmtServiceRequestAndPrint(docMgmtService);
      docMgmtService = getDocumentManagementService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.HTTP_BASIC_AUTH_SSL);
      doDocMgmtServiceRequestAndPrint(docMgmtService);
      docMgmtService = getDocumentManagementService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.WSS_USERNAME_TOKEN);
      doDocMgmtServiceRequestAndPrint(docMgmtService);
   }

   private static void doUserServiceRequest() throws BpmFault
   {
      System.out.print("\n\nUser Service:\n-------------\n");
      IUserService userService;
      userService = getUserService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.HTTP_BASIC_AUTH);
      doUserServiceRequestAndPrint(userService);
      userService = getUserService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.HTTP_BASIC_AUTH_SSL);
      doUserServiceRequestAndPrint(userService);
      userService = getUserService(MOTU_USERNAME, MOTU_PWD, SESSION_PROPERTIES,
            AuthMode.WSS_USERNAME_TOKEN);
      doUserServiceRequestAndPrint(userService);
   }

   private static void doAdminServiceRequest() throws BpmFault
   {
      System.out.print("\n\nAdministration Service:\n-----------------------\n");
      IAdministrationService adminService;
      adminService = getAdministrationService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.HTTP_BASIC_AUTH);
      doAdminServiceRequestAndPrint(adminService);
      adminService = getAdministrationService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.HTTP_BASIC_AUTH_SSL);
      doAdminServiceRequestAndPrint(adminService);
      adminService = getAdministrationService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.WSS_USERNAME_TOKEN);
      doAdminServiceRequestAndPrint(adminService);
   }

   private static void doWfServiceRequestAndPrint(final IWorkflowService wfService)
         throws BpmFault
   {
      final UserXto user = wfService.getSessionUser();
      printUser(user);
   }

   private static void doQueryServiceRequestAndPrint(final IQueryService queryService)
         throws BpmFault
   {
      final PermissionsXto permissions = queryService.getPermissions();
      final List<PermissionXto> permissionList = permissions.getPermission();
      final Iterator<PermissionXto> permissionIter = permissionList.iterator();
      while (permissionIter.hasNext())
      {
         System.out.print(permissionIter.next().getPermissionId());
         if (permissionIter.hasNext())
         {
            System.out.print(", ");
         }
      }
      System.out.println();
   }

   private static void doDocMgmtServiceRequestAndPrint(
         final IDocumentManagementService docMgmtService) throws BpmFault
   {
      final String folderName = "Test";

      final FolderInfoXto folderInfo = new FolderInfoXto();
      folderInfo.setName(folderName);
      folderInfo.setDescription("This is a test.");
      final FolderXto folder = docMgmtService.createFolder("/", folderInfo);
      System.out.println(folder.getName() + ": " + folder.getDescription() + "(ID: "
            + folder.getId() + ")");

      docMgmtService.removeFolder(folder.getId(), false);
   }

   private static void doUserServiceRequestAndPrint(final IUserService userService)
         throws BpmFault
   {
      final UserXto user = userService.getSessionUser();
      printUser(user);
   }

   private static void doAdminServiceRequestAndPrint(
         final IAdministrationService adminService) throws BpmFault
   {
      final UserXto user = adminService.getSessionUser();
      printUser(user);
   }

   private static void printUser(final UserXto user)
   {
      System.out.println(user.getFirstName() + " " + user.getLastName());
   }

   private static Map<String, String> initSessionProperties()
   {
      final Map<String, String> sessionProperties = CollectionUtils.newHashMap();
      sessionProperties.put(SecurityProperties.PARTITION, "default");
      sessionProperties.put(SecurityProperties.REALM, "carnot");
      sessionProperties.put(SecurityProperties.DOMAIN, "default");
      return sessionProperties;
   }
}
