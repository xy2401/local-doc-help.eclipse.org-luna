﻿using System;
using com.infinity.bpm.api;
using System.Collections.Generic;

namespace InfinityWsClient
{
    /// <summary>
    /// This example illustrates how to use the WS Query API correctly. The following three main facts should be kept in mind:
    /// 1. The Query and Query element types, you eventually use to do a query call, are located in namespace 
    ///    <code>com.infinity.bpm.api.query.stubs</code>.
    /// 2. The Query element types (order criteria, policy and predicate), you should use to build a query element, are located in
    ///    namespace <code>com.infinity.bpm.api.query</code>.
    /// 3. Conversion from query element types in namespace <code>com.infinity.bpm.api.query</code> to the corresponding type in namespace
    ///    <code>com.infinity.bpm.api.query.stubs</code> is done by an appropriate property contained in the latter type. This conversion
    ///    is needed as the query API only expects query element types of namespace <code>com.infinity.bpm.api.query.stubs</code>.
    /// </summary>
    class WsClientQueryExampleApp
    {
        private const String MOTU_USERNAME = "motu";
        private const String MOTU_PWD = "motu";

        private static readonly IQueryService QUERY_SERVICE;

        static WsClientQueryExampleApp()
        {
            QUERY_SERVICE = WsFactory.GetQueryService(MOTU_USERNAME, MOTU_PWD, new Dictionary<String, String>(), 
                WsFactory.AuthenticationMode.HttpBasicAuthentication);
        }

        /// <summary>
        /// Assembles the query with types of namespace <code>com.infinity.bpm.api.query.stubs</code> and invokes it.
        /// </summary>
        static void Main(String[] args)
        {
            com.infinity.bpm.api.query.stubs.ProcessQuery processQuery = new com.infinity.bpm.api.query.stubs.ProcessQuery();
            processQuery.order = CreateOrderCriteria();
            processQuery.policy = CreatePolicy();
            processQuery.predicate = CreatePredicate();

            ProcessInstanceQueryResult piqr = QUERY_SERVICE.findProcesses(processQuery);
            foreach (ProcessInstance pi in piqr.processInstances)
            {
                Console.WriteLine("Found process instance with OID {0} in state {1}.", pi.oid, pi.state);
            }
        }

        /// <summary>
        /// Creates an order criteria using <code>com.infinity.bpm.api.query.OrderCriteria</code> and eventually
        /// converts it to an order criteria of type <code>com.infinity.bpm.api.query.stubs.OrderCriteria</code>
        /// using the property <code>com.infinity.bpm.api.query.stubs.OrderCriteria#QueryOrderCriteria</code>.
        /// </summary>
        private static com.infinity.bpm.api.query.stubs.OrderCriteria CreateOrderCriteria()
        {
            com.infinity.bpm.api.query.DataOrder dataOrder = new com.infinity.bpm.api.query.DataOrder();
            dataOrder.ascending = false;
            dataOrder.dataId = "PROCESS_ID";
            dataOrder.attribute = "oid";

            com.infinity.bpm.api.query.OrderCriteria orderCriteria = new com.infinity.bpm.api.query.OrderCriteria();
            orderCriteria.Items = new com.infinity.bpm.api.query.OrderCriterion[1];
            orderCriteria.Items[0] = dataOrder;

            com.infinity.bpm.api.query.stubs.OrderCriteria expectedOrderCriteria = new com.infinity.bpm.api.query.stubs.OrderCriteria();
            expectedOrderCriteria.QueryOrderCriteria = orderCriteria;
            return expectedOrderCriteria;
        }

        /// <summary>
        /// Creates a policy using <code>com.infinity.bpm.api.query.Policy</code> and eventually
        /// converts it to an order criteria of type <code>com.infinity.bpm.api.query.stubs.Policy</code>
        /// using the property <code>com.infinity.bpm.api.query.stubs.Policy#QueryPolicy</code>.
        /// </summary>
        private static com.infinity.bpm.api.query.stubs.Policy CreatePolicy()
        {
            com.infinity.bpm.api.query.DescriptorPolicy descriptorPolicy = new com.infinity.bpm.api.query.DescriptorPolicy();
            descriptorPolicy.includeDescriptors = true;

            com.infinity.bpm.api.query.HistoricalEventPolicy historicalEventPolicy = new com.infinity.bpm.api.query.HistoricalEventPolicy();
            historicalEventPolicy.eventTypes = HistoricalEventType.StateChange.ToString();

            com.infinity.bpm.api.query.HistoricalStatesPolicy historicalStatesPolicy = new com.infinity.bpm.api.query.HistoricalStatesPolicy();
            historicalStatesPolicy.includeHistoricalStates = true;

            com.infinity.bpm.api.query.ModelVersionPolicy modelVersionPolicy = new com.infinity.bpm.api.query.ModelVersionPolicy();
            modelVersionPolicy.restrictedToActiveModel = false;

            com.infinity.bpm.api.query.ProcessInstanceDetailsPolicy processInstanceDetailsPolicy = new com.infinity.bpm.api.query.ProcessInstanceDetailsPolicy();
            processInstanceDetailsPolicy.detailsLevel = com.infinity.bpm.api.query.ProcessInstanceDetailsLevel.Full;

            com.infinity.bpm.api.query.SubsetPolicy subsetPolicy = new com.infinity.bpm.api.query.SubsetPolicy();
            subsetPolicy.evaluateTotalCount = true;
            subsetPolicy.maxSize = 100;
            subsetPolicy.skippedEntries = 2;

            com.infinity.bpm.api.query.Policy policy = new com.infinity.bpm.api.query.Policy();
            policy.descriptorPolicy = descriptorPolicy;
            policy.historicalEventPolicy = historicalEventPolicy;
            policy.historicalStatesPolicy = historicalStatesPolicy;
            policy.modelVersionPolicy = modelVersionPolicy;
            policy.processInstanceDetailsPolicy = processInstanceDetailsPolicy;
            policy.subsetPolicy = subsetPolicy;

            com.infinity.bpm.api.query.stubs.Policy expectedPolicy = new com.infinity.bpm.api.query.stubs.Policy();
            expectedPolicy.QueryPolicy = policy;
            return expectedPolicy;
        }

        /// <summary>
        /// Creates an order criteria using <code>com.infinity.bpm.api.query.AndTerm</code> and eventually
        /// converts it to an order criteria of type <code>com.infinity.bpm.api.query.stubs.AndTerm</code>
        /// using the property <code>com.infinity.bpm.api.query.stubs.AndTerm#QueryAndTerm</code>.
        /// </summary>
        private static com.infinity.bpm.api.query.stubs.AndTerm CreatePredicate()
        {
            com.infinity.bpm.api.query.ProcessStateFilter processStateFilter = new com.infinity.bpm.api.query.ProcessStateFilter();
            processStateFilter.states = new com.infinity.bpm.api.query.ProcessStateFilterStates();
            processStateFilter.states.state = new com.infinity.bpm.api.query.ProcessInstanceState[1];
            processStateFilter.states.state[0] = com.infinity.bpm.api.query.ProcessInstanceState.Active;

            com.infinity.bpm.api.query.AndTerm andTerm = new com.infinity.bpm.api.query.AndTerm();
            andTerm.Items = new com.infinity.bpm.api.query.PredicateBase[1];
            andTerm.Items[0] = processStateFilter;

            com.infinity.bpm.api.query.stubs.AndTerm expectedAndTerm = new com.infinity.bpm.api.query.stubs.AndTerm();
            expectedAndTerm.QueryAndTerm = andTerm;
            return expectedAndTerm;
        }
    }
}