/*******************************************************************************
 * Copyright (c) 2000, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/

package org.eclipse.stardust.examples.wsclient;

import static org.eclipse.stardust.common.CollectionUtils.newHashMap;

import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.ws.addressing.WSAddressingFeature;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSPasswordCallback;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.eclipse.stardust.common.Pair;
import org.eclipse.stardust.common.StringUtils;
import org.eclipse.stardust.common.error.ErrorCase;
import org.eclipse.stardust.common.error.PublicException;
import org.eclipse.stardust.common.log.LogManager;
import org.eclipse.stardust.common.log.Logger;
import org.eclipse.stardust.engine.api.runtime.BpmRuntimeError;
import org.eclipse.stardust.engine.core.runtime.beans.removethis.SecurityProperties;

import org.eclipse.stardust.engine.api.ws.IAdministrationService;
import org.eclipse.stardust.engine.api.ws.IDocumentManagementService;
import org.eclipse.stardust.engine.api.ws.IQueryService;
import org.eclipse.stardust.engine.api.ws.IUserService;
import org.eclipse.stardust.engine.api.ws.IWorkflowService;

/**
 * <p>
 * Provides access to Java abstractions of the following Web Services
 * </p>
 * <ul>
 * <li>Workflow Service</li>
 * <li>Query Service</li>
 * <li>Document Management Service</li>
 * <li>User Service</li>
 * <li>Administration Service</li>
 * </ul>
 * 
 * @author nicolas.werlein
 * @version $Revision: $
 */
public class WsFactory
{
   public static final String WS_PROPERTIES_FILE_NAME = "product-ws.properties";

   public static final String WEB_SERVICE_HOST = "WebService.Host";

   public static final String WEB_SERVICE_SSL_PORT = "WebService.SslPort";

   public static final String WEB_SERVICE_PORT = "WebService.Port";

   public static final String WEB_SERVICE_CTX_ROOT = "WebService.ContextRoot";

   private static final Logger LOGGER = LogManager.getLogger(WsFactory.class);

   private static final String PRODUCT_SERVICE_NS = "http://eclipse.org/bpm/ws/v2012a/api";

   private static final String HTTP_BASIC_AUTH = "HttpBasicAuth";

   private static final String HTTP_BASIC_AUTH_SSL = "HttpBasicAuthSsl";

   private static final String WSS_USERNAME_TOKEN = "WssUsernameToken";

   private static final String WORKFLOW_SERVICE = "WorkflowService";

   private static final String QUERY_SERVICE = "QueryService";

   private static final String DOCUMENT_MGMT_SERVICE = "DocumentManagementService";

   private static final String USER_SERVICE = "UserService";

   private static final String ADMIN_SERVICE = "AdministrationService";

   private static final String REF_PARAM_PARTITION = "stardust-bpm-partition";

   private static final String REF_PARAM_REALM = "stardust-bpm-realm";

   private static final String REF_PARAM_DOMAIN = "stardust-bpm-domain";

   private static final String ADDRESSING_PREFIX = "wsa";

   private static final String ADDRESSING_NS_URI = "http://www.w3.org/2005/08/addressing";

   private static final Map<String, String> SESSION_PROPERTY_2_REF_PARAMETER;

   private static final Map<Pair<Class< ? >, AuthMode>, String> SERVICE_URLS;

   static
   {
      enableLocalhostModeForSSL();

      SESSION_PROPERTY_2_REF_PARAMETER = initSessionProperty2RefParameterMap();

      final Pair<String, String> urls = resolveUrlPrefix();
      SERVICE_URLS = initServiceUrls(urls.getFirst(), urls.getSecond());
   }

   public static IWorkflowService getWorkflowService(final String username,
         final String pwd, final Map<String, String> sessionProperties,
         final AuthMode authMode)
   {
      return getService(IWorkflowService.class, username, pwd, sessionProperties,
            authMode);
   }

   public static IQueryService getQueryService(final String username, final String pwd,
         final Map<String, String> sessionProperties, final AuthMode authMode)
   {
      return getService(IQueryService.class, username, pwd, sessionProperties, authMode);
   }

   public static IDocumentManagementService getDocumentManagementService(
         final String username, final String pwd,
         final Map<String, String> sessionProperties, final AuthMode authMode)
   {
      return getService(IDocumentManagementService.class, username, pwd,
            sessionProperties, authMode);
   }

   public static IUserService getUserService(final String username, final String pwd,
         final Map<String, String> sessionProperties, final AuthMode authMode)
   {
      return getService(IUserService.class, username, pwd, sessionProperties, authMode);
   }

   public static IAdministrationService getAdministrationService(final String username,
         final String pwd, final Map<String, String> sessionProperties,
         final AuthMode authMode)
   {
      return getService(IAdministrationService.class, username, pwd, sessionProperties,
            authMode);
   }

   private static <T> T getService(final Class<T> clazz, final String username,
         final String pwd, final Map<String, String> sessionProperties,
         final AuthMode authMode)
   {
      final String serviceAddress = SERVICE_URLS.get(new Pair<Class< ? >, AuthMode>(
            clazz, authMode));

      final JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
      factory.setServiceClass(clazz);
      factory.setAddress(serviceAddress);

      factory.getFeatures().add(new WSAddressingFeature());
      factory.getHandlers().add(new SessionPropertyHandler(sessionProperties));

      factory.getOutInterceptors().add(new LoggingOutInterceptor());

      if (authMode == AuthMode.WSS_USERNAME_TOKEN)
      {
         final Map<String, Object> properties = newHashMap();
         properties.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
         properties.put(WSHandlerConstants.USER, username);
         properties.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
         properties.put(WSHandlerConstants.PW_CALLBACK_REF,
               new UsernameTokenPasswordCallback(pwd));

         final WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(properties);
         factory.getOutInterceptors().add(wssOut);
      }
      else
      {
         factory.setUsername(username);
         factory.setPassword(pwd);
      }

      @SuppressWarnings("unchecked")
      final T service = (T) factory.create();

      if (authMode == AuthMode.HTTP_BASIC_AUTH_SSL
            || authMode == AuthMode.WSS_USERNAME_TOKEN)
      {
         disableCNCheck(service);
      }

      return service;
   }

   private static Pair<String, String> resolveUrlPrefix()
   {
      final Map<String, String> props = readExternalProperties();
      final String host = props.get(WEB_SERVICE_HOST);
      final String port = props.get(WEB_SERVICE_PORT);
      final String sslPort = props.get(WEB_SERVICE_SSL_PORT);
      final String contextRoot = props.get(WEB_SERVICE_CTX_ROOT);

      if (StringUtils.isEmpty(host) || StringUtils.isEmpty(sslPort)
            || StringUtils.isEmpty(contextRoot))
      {
         throw new WsFactoryException(
               BpmRuntimeError.IPPWS_FACTORY_WS_PROPERTIES_MISSING.raise(
                     WEB_SERVICE_HOST, WEB_SERVICE_SSL_PORT, WEB_SERVICE_CTX_ROOT));
      }

      return new Pair<String, String>("http://" + host + ":" + port + "/" + contextRoot
            + "/services/soap/", "https://" + host + ":" + sslPort + "/" + contextRoot
            + "/services/soap/");
   }

   private static Map<String, String> readExternalProperties()
   {
      final Map<String, String> propMap;
      try
      {
         final URL cfgFileUri = WsFactory.class.getClassLoader().getResource(
               WS_PROPERTIES_FILE_NAME);
         final Properties props = new Properties();
         props.load(cfgFileUri.openStream());
         @SuppressWarnings({"rawtypes", "unchecked"})
         final Map<String, String> tempMap = (Map) props;
         propMap = new HashMap<String, String>(tempMap);

         LOGGER.debug("Resolved Web Service Properties to " + propMap);
      }
      catch (final Exception e)
      {
         final ErrorCase errorCase = BpmRuntimeError.IPPWS_FACTORY_FAILED_RESOLVING_WS_PROPERTIES.raise();
         LOGGER.error(errorCase.toString(), e);
         throw new WsFactoryException(errorCase, e);
      }
      return propMap;
   }

   private static Map<String, String> initSessionProperty2RefParameterMap()
   {
      final Map<String, String> map = newHashMap();
      map.put(SecurityProperties.PARTITION, REF_PARAM_PARTITION);
      map.put(SecurityProperties.REALM, REF_PARAM_REALM);
      map.put(SecurityProperties.DOMAIN, REF_PARAM_DOMAIN);
      return map;
   }

   private static Map<Pair<Class< ? >, AuthMode>, String> initServiceUrls(
         final String httpAddress, final String httpsAddress)
   {
      final Map<Pair<Class< ? >, AuthMode>, String> map = newHashMap();

      map.put(new Pair<Class< ? >, AuthMode>(IWorkflowService.class,
            AuthMode.HTTP_BASIC_AUTH), httpAddress + WORKFLOW_SERVICE + HTTP_BASIC_AUTH);
      map.put(new Pair<Class< ? >, AuthMode>(IWorkflowService.class,
            AuthMode.HTTP_BASIC_AUTH_SSL), httpsAddress + WORKFLOW_SERVICE
            + HTTP_BASIC_AUTH_SSL);
      map.put(new Pair<Class< ? >, AuthMode>(IWorkflowService.class,
            AuthMode.WSS_USERNAME_TOKEN), httpsAddress + WORKFLOW_SERVICE
            + WSS_USERNAME_TOKEN);

      map.put(new Pair<Class< ? >, AuthMode>(IQueryService.class,
            AuthMode.HTTP_BASIC_AUTH), httpAddress + QUERY_SERVICE + HTTP_BASIC_AUTH);
      map.put(new Pair<Class< ? >, AuthMode>(IQueryService.class,
            AuthMode.HTTP_BASIC_AUTH_SSL), httpsAddress + QUERY_SERVICE
            + HTTP_BASIC_AUTH_SSL);
      map.put(new Pair<Class< ? >, AuthMode>(IQueryService.class,
            AuthMode.WSS_USERNAME_TOKEN), httpsAddress + QUERY_SERVICE
            + WSS_USERNAME_TOKEN);

      map.put(new Pair<Class< ? >, AuthMode>(IDocumentManagementService.class,
            AuthMode.HTTP_BASIC_AUTH), httpAddress + DOCUMENT_MGMT_SERVICE
            + HTTP_BASIC_AUTH);
      map.put(new Pair<Class< ? >, AuthMode>(IDocumentManagementService.class,
            AuthMode.HTTP_BASIC_AUTH_SSL), httpsAddress + DOCUMENT_MGMT_SERVICE
            + HTTP_BASIC_AUTH_SSL);
      map.put(new Pair<Class< ? >, AuthMode>(IDocumentManagementService.class,
            AuthMode.WSS_USERNAME_TOKEN), httpsAddress + DOCUMENT_MGMT_SERVICE
            + WSS_USERNAME_TOKEN);

      map.put(
            new Pair<Class< ? >, AuthMode>(IUserService.class, AuthMode.HTTP_BASIC_AUTH),
            httpAddress + USER_SERVICE + HTTP_BASIC_AUTH);
      map.put(new Pair<Class< ? >, AuthMode>(IUserService.class,
            AuthMode.HTTP_BASIC_AUTH_SSL), httpsAddress + USER_SERVICE
            + HTTP_BASIC_AUTH_SSL);
      map.put(new Pair<Class< ? >, AuthMode>(IUserService.class,
            AuthMode.WSS_USERNAME_TOKEN), httpsAddress + USER_SERVICE
            + WSS_USERNAME_TOKEN);

      map.put(new Pair<Class< ? >, AuthMode>(IAdministrationService.class,
            AuthMode.HTTP_BASIC_AUTH), httpAddress + ADMIN_SERVICE + HTTP_BASIC_AUTH);
      map.put(new Pair<Class< ? >, AuthMode>(IAdministrationService.class,
            AuthMode.HTTP_BASIC_AUTH_SSL), httpsAddress + ADMIN_SERVICE
            + HTTP_BASIC_AUTH_SSL);
      map.put(new Pair<Class< ? >, AuthMode>(IAdministrationService.class,
            AuthMode.WSS_USERNAME_TOKEN), httpsAddress + ADMIN_SERVICE
            + WSS_USERNAME_TOKEN);

      return map;
   }

   private static void enableLocalhostModeForSSL()
   {
      HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier()
      {
         public boolean verify(String hostname, SSLSession sslSession)
         {
            if (hostname.equals("localhost"))
            {
               return true;
            }
            return false;
         }
      });
   }

   private static void disableCNCheck(final Object service)
   {
      final Client client = ClientProxy.getClient(service);
      final HTTPConduit httpConduit = (HTTPConduit) client.getConduit();
      final TLSClientParameters params = new TLSClientParameters();
      params.setDisableCNCheck(true);
      httpConduit.setTlsClientParameters(params);
   }

   /**
    * @author nicolas.werlein
    * @version $Revision: $
    */
   public enum AuthMode {
      HTTP_BASIC_AUTH, HTTP_BASIC_AUTH_SSL, WSS_USERNAME_TOKEN
   }

   private static final class SessionPropertyHandler
         implements SOAPHandler<SOAPMessageContext>
   {
      private final Map<String, String> sessionProperties;

      public SessionPropertyHandler(final Map<String, String> sessionProperties)
      {
         if (sessionProperties == null)
         {
            this.sessionProperties = Collections.emptyMap();
         }
         else
         {
            this.sessionProperties = sessionProperties;
         }
      }

      public Set<QName> getHeaders()
      {
         return Collections.emptySet();
      }

      public void close(final MessageContext ctx)
      {
         /* nothing to do */
      }

      public boolean handleFault(final SOAPMessageContext ctx)
      {
         return true;
      }

      public boolean handleMessage(final SOAPMessageContext ctx)
      {
         final Boolean isOutbound = (Boolean) ctx.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY);
         if ( !isOutbound)
            return true;

         try
         {
            final SOAPHeader header = ctx.getMessage().getSOAPHeader();
            if (header == null)
            {
               throw new WsFactoryException(
                     BpmRuntimeError.IPPWS_FACTORY_FAILED_ADDING_SESSION_PROP_TO_NONEXISTING_SOAP_HEADER.raise());
            }

            for (final String key : sessionProperties.keySet())
            {
               final String refParameterName = SESSION_PROPERTY_2_REF_PARAMETER.get(key);
               if (refParameterName == null)
               {
                  LOGGER.warn("Ignoring unknown Session Property: " + key);
                  continue;
               }
               final SOAPHeaderElement headerElement = header.addHeaderElement(new QName(
                     PRODUCT_SERVICE_NS, refParameterName));
               final String qualifiedName = ADDRESSING_PREFIX + ":IsReferenceParameter";
               headerElement.setAttributeNS(ADDRESSING_NS_URI, qualifiedName, "1");
               headerElement.addTextNode(sessionProperties.get(key));
            }
         }
         catch (final SOAPException e)
         {
            throw new WsFactoryException(
                  BpmRuntimeError.IPPWS_FACTORY_FAILED_ADDING_SESSION_PROP_TO_SOAP_HEADER.raise(),
                  e);
         }

         return true;
      }
   }

   private static final class UsernameTokenPasswordCallback implements CallbackHandler
   {
      private final String pwd;

      public UsernameTokenPasswordCallback(final String pwd)
      {
         if (pwd == null)
         {
            throw new NullPointerException("Password must not be null.");
         }
         this.pwd = pwd;
      }

      public void handle(final Callback[] callbacks) throws IOException,
            UnsupportedCallbackException
      {
         final WSPasswordCallback pc = (WSPasswordCallback) callbacks[0];
         pc.setPassword(pwd);
      }
   }

   private static final class WsFactoryException extends PublicException
   {
      private static final long serialVersionUID = 195864783280814405L;

      public WsFactoryException(final ErrorCase errorCase, final Exception e)
      {
         super(errorCase, e);
      }

      public WsFactoryException(final ErrorCase errorCase)
      {
         super(errorCase);
      }
   }
}
