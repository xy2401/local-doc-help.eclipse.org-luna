********************************************

Scoped Participant Examples

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The examples provided in these section demonstrate the usage of departments as 
runtime instances of organizations. It contains the example models, which are 
used in the according tutorials.

Tutorials

Please find the according tutorials in the Tutorial Guide of the documentation:

 * The Multi-scoped Participant Example
      - a simple use case created to explain how to develop a multi-scoped organizational structure and
        work with multi-scoped participants
 * Using Declarative Security for Scoped Participants in Report Viewing tutorial 
      - a simple use case example on how declarative
        security affects report data visibility for users in different
        departments
 * Delegating to a User in Another Target Department
      - a simple use case example on how to delegate a user to a user in another
        target department