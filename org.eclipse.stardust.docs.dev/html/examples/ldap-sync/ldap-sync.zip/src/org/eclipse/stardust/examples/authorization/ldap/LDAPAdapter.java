/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000-2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.ldap;

import java.util.*;

import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.eclipse.stardust.common.CollectionUtils;
import org.eclipse.stardust.common.StringUtils;
import org.eclipse.stardust.common.config.Parameters;
import org.eclipse.stardust.common.error.InternalException;
import org.eclipse.stardust.common.error.LoginFailedException;
import org.eclipse.stardust.common.log.LogManager;
import org.eclipse.stardust.common.log.Logger;
import org.eclipse.stardust.engine.core.runtime.beans.removethis.SecurityProperties;
import org.eclipse.stardust.engine.core.spi.security.ExternalLoginResult;
import org.eclipse.stardust.engine.core.spi.security.ExternalUserConfiguration.GrantInfo;


/**
 * Serves as a worker for the synchronization provider, doing the real data retrieval.
 * 
 * @author swoelk, ubirkemeyer
 * @version $Revision$
 */
public final class LDAPAdapter
{
   public static final Logger trace = LogManager.getLogger(LDAPAdapter.class);

   /**
    * The value that the LDAPSynchronization.BindMode property has to have if the data
    * retrieval connection will be used in anonymous mode.
    */
   public static final String BIND_MODE_ANONYMOUS = "anonymous";

   /**
    * The value that the LDAPSynchronization.BindMode property has to have if the data
    * retrieval will be done with a concrete account.
    */
   public static final String BIND_MODE_DEDICATED = "dedicated";

   private static final String ORG_DEPT_DELIM_LEFT = "<";
   
   private static final char ORG_DEPT_DELIM_RIGHT = '>';
   
   private static final String DEPT_DELIM = ",";

   /**
    * The singleton instance.
    */
   private static LDAPAdapter instance = null;
   
   /**
    * The base DN below which the person objects are searched in the directory tree.
    */
   private String rootDN = null;

   private String userBaseDN = null;

   private String departmentBaseDN = null;
   
   private String groupBaseDN = null;

   private int userQueryScope;

   private int groupQueryScope;

   /**
    * The connection to the LDAP server
    */
   private LDAPConnection connection = null;

   private int searchTimeLimit = 0;

   private String participantIDAttribute;

   private String userLastnameAttribute;

   private String userFirstnameAttribute;

   private String userDescriptionAttribute;

   private String userEmailAttribute;

   private List<String> userAdditionalAttributes;

   private String departmentNameAttribute;
   
   private String departmentDescriptionAttribute;
   
   /**
    * Singleton accessor.
    */
   public static LDAPAdapter instance()
   {
      if (instance == null)
      {
         instance = new LDAPAdapter();
      }
      return instance;
   }

   /**
    * The constructor is private to implement correct singleton behaviour
    */
   private LDAPAdapter()
   {
      String ldapServerHost = Parameters.instance().getString(
            LDAPProperties.LDAP_SERVER_HOST_PROPERTY);
      int ldapServerPort = Parameters.instance().getInteger(
            LDAPProperties.LDAP_SERVER_PORT_PROPERTY, 389);

      rootDN = Parameters.instance().getString(LDAPProperties.ROOT_DN_PROPERTY);
      userBaseDN = Parameters.instance().getString(LDAPProperties.USER_BASE_DN_PROPERTY,
            "");
      departmentBaseDN = Parameters.instance().getString(
            LDAPProperties.DEPARTMENT_BASE_DN_PROPERTY, "");
      groupBaseDN = Parameters.instance().getString(
            LDAPProperties.GROUP_BASE_DN_PROPERTY, "");
      userQueryScope = Parameters.instance().getInteger(LDAPProperties.USER_QUERY_SCOPE,
            SearchControls.SUBTREE_SCOPE);
      groupQueryScope = Parameters.instance().getInteger(
            LDAPProperties.GROUP_QUERY_SCOPE, SearchControls.SUBTREE_SCOPE);

      trace.info("Connecting to host: '" + ldapServerHost + "', root dn: '" + rootDN
            + "'.");

      if ((ldapServerHost == null) || (rootDN == null))
      {
         throw new InternalException("One or more of the mandatory properties "
               + LDAPProperties.LDAP_SERVER_HOST_PROPERTY + " or "
               + LDAPProperties.ROOT_DN_PROPERTY + " are missing");
      }

      connection = new LDAPConnection("ldap://" + ldapServerHost + ":" + ldapServerPort
            + "/" + rootDN);

      String retrievalMode = Parameters.instance().getString(
            LDAPProperties.BIND_MODE_PROPERTY, BIND_MODE_ANONYMOUS);

      if (retrievalMode.compareToIgnoreCase(BIND_MODE_DEDICATED) == 0)
      {
         connection.setUserInfo(Parameters.instance().getString(
               LDAPProperties.BIND_USER_PROPERTY), Parameters.instance().getString(
               LDAPProperties.BIND_PASSWORD_PROPERTY));
      }

      searchTimeLimit = Parameters.instance().getInteger(
            LDAPProperties.SEARCH_TIME_LIMIT_PROPERTY, 0);
      participantIDAttribute = Parameters.instance().getString(
            LDAPProperties.PARTICIPANT_ID_ATT_PROPERTY, "cn");
      userLastnameAttribute = Parameters.instance().getString(
            LDAPProperties.USER_LASTNAME_ATT_PROPERTY, "sn");
      userFirstnameAttribute = Parameters.instance().getString(
            LDAPProperties.USER_FIRSTNAME_ATT_PROPERTY, "givenname");
      userDescriptionAttribute = Parameters.instance().getString(
            LDAPProperties.USER_DESCRIPTION_ATT_PROPERTY, "description");
      userEmailAttribute = Parameters.instance().getString(
            LDAPProperties.USER_EMAIL_ATT_PROPERTY, "mail");

      userAdditionalAttributes = new ArrayList<String>();
      String additionalAttributes = Parameters.instance().getString(
            LDAPProperties.USER_ADDITIONAL_ATT_PROPERTY, "");

      if ((null != additionalAttributes) && (!additionalAttributes.equals("")))
      {
         StringTokenizer tokenizer = new StringTokenizer(additionalAttributes, ",");

         while (tokenizer.hasMoreTokens())
         {
            userAdditionalAttributes.add(tokenizer.nextToken());
         }
      }
      
      departmentNameAttribute = Parameters.instance().getString(
            LDAPProperties.DEPARTMENT_NAME_ATT_PROPERTY, "ou");
      departmentDescriptionAttribute = Parameters.instance().getString(
            LDAPProperties.DEPARTMENT_DESCRIPTION_ATT_PROPERTY, "description");
   }
   
   /**
    * Checks whether the given user/pwd pair exist in the LDAP directory.
    * 
    * @param user the username
    * @param pwd the password
    * @param properties additional properties, e.g. realm or partition
    * @return <code>ExternalLoginResult</code> with field <code>succeeded</code> set
    *          to <code>true</code>, if login was successful, <code>false</code> otherwise
    */
   public ExternalLoginResult login(final String user, final String pwd,
         Map<?,?> properties)
   {
      final String realm = (String) properties.get(SecurityProperties.REALM);
      final String partition = (String) properties.get(SecurityProperties.PARTITION);

      trace.debug("Trying to log in " + user + ", " + realm
            + " in partition " + partition);
      
      final LDAPConnection tempConn = new LDAPConnection(null);
      try
      {
         final String userDn = "uid=" + getQualifiedName(user);
         tempConn.setUserInfo(userDn, pwd);
         
         tempConn.getContext();
         
         trace.debug("Login of user " + user + " and realm " + realm + " was successful.");
         return ExternalLoginResult.testifySuccess(properties);
      }
      catch (LoginFailedException e)
      {
         return ExternalLoginResult.testifyFailure(e);
      }
      finally
      {
         try
         {
            tempConn.disconnect();
         }
         catch (Exception e)
         {
            trace.error("Unable to disconnect from LDAP", e);
         }
      }
   }
   
   private String getQualifiedName(String userId)
   {
      StringBuilder qualifiedName = new StringBuilder(userId);
      if(StringUtils.isNotEmpty(userBaseDN) && StringUtils.isNotEmpty(rootDN))
      {
         qualifiedName.append(",").append(userBaseDN).append(",").append(rootDN);
      }
      return qualifiedName.toString();
   }

   /**
    * @param principal
    *           the plain name of the person to load.
    * @return an
    */
   public LDAPPerson getPerson(String principal)
   {
      LDAPPerson result = new LDAPPerson();

      String filter = StringUtils.replace(Parameters.instance().getString(
            LDAPProperties.USER_FILTER_PROPERTY), "%v", principal);

      trace.debug("Using filter: '" + filter + "'.");
      try
      {
         DirContext dctx = connection.getContext();

         SearchControls searchControls = new SearchControls();
         searchControls.setSearchScope(userQueryScope);
         searchControls.setTimeLimit(searchTimeLimit);
         
         String ou = getOrganizationalUnits(dctx);

         NamingEnumeration<SearchResult> searchResults = dctx
               .search(ou, filter, searchControls);

         if (searchResults.hasMore())
         {
            SearchResult searchResult = searchResults.next();

            result.setExisting(true);
            
            result.setRdn(principal);
            
            Attributes attributes = searchResult.getAttributes();
            
            result.setLastName((String) attributes.get(userLastnameAttribute).get());

            result.setFirstName(getAttributeValue(attributes, userFirstnameAttribute));
            result.setEMail(getAttributeValue(attributes, userEmailAttribute));
            result
                  .setDescription(getAttributeValue(attributes, userDescriptionAttribute));

            Iterator<String> additionalIt = userAdditionalAttributes.iterator();
            while (additionalIt.hasNext())
            {
               String attributeName = additionalIt.next();
               result.setUserProperty(attributeName, getAttributeValue(attributes,
                     attributeName));
            }
         }
         else
         {
            trace.info("No match found in directory for principal '" + principal + "'.");
         }
      }
      catch (Exception e)
      {
         trace.warn("", e);
      }
      return result;
   }

   public LDAPDepartment getDepartment(final String participantId,
         final List<String> departmentKey)
   {
      LDAPDepartment ldapDept;
      
      final String deptStr = createDeptStringFrom(participantId, departmentKey);
      final String filter = StringUtils.replace(Parameters.instance().getString(
            LDAPProperties.DEPARTMENT_FILTER_PROPERTY), "%v", deptStr);
      trace.debug("Using filter: '" + filter + "'.");
      
      try
      {
         NamingEnumeration<SearchResult> result = searchForDepartment(filter);
         if (result.hasMore())
         {
            ldapDept = createLdapDepartment(result.next());
         }
         else
         {
            ldapDept = null;
         }
      }
      catch (Exception e)
      {
         trace.warn("Failed to find department: " + deptStr, e);
         ldapDept = null;
      }
      
      return ldapDept;
   }
   
   private String createDeptStringFrom(final String participantId,
         final List<String> departmentKey)
   {
      final StringBuilder sb = new StringBuilder();
      sb.append(participantId);
      if ( !departmentKey.isEmpty())
      {
         sb.append(ORG_DEPT_DELIM_LEFT);         
         for (final String s : departmentKey)
         {
            sb.append(s + DEPT_DELIM);
         }
         sb.setCharAt(sb.length() - 1, ORG_DEPT_DELIM_RIGHT);
      }
      return sb.toString();
   }
   
   private String getOrganizationalUnits(DirContext ctx)
   {
      StringBuffer ou = new StringBuffer();
      if(StringUtils.isNotEmpty(userBaseDN))
      {
         try
         {
            Name jndiName = ctx.getNameParser( "" ).parse( userBaseDN );
            Enumeration<String> nameEnum = jndiName.getAll();
            while(nameEnum.hasMoreElements())
            {
               String name = nameEnum.nextElement();
               if(name.toLowerCase().startsWith("ou="))
               {
                  if(ou.length() != 0)
                  {
                     ou.append(",");
                  }
                  ou.append(name);
               }
            }
         }
         catch (NamingException e) 
         {
            trace.warn("unable to extract organizational units from userBaseDN", e);
         }
      }
      return ou.toString();
   }

   private String getAttributeValue(Attributes attributes, String name)
         throws NamingException
   {
      Attribute att = attributes.get(name);
      return att == null ? "" : (String) att.get();
   }

   private NamingEnumeration<SearchResult> searchForDepartment(final String filter)
         throws NamingException
   {
      final DirContext dctx = connection.getContext();

      final SearchControls searchControls = new SearchControls();
      searchControls.setSearchScope(userQueryScope);
      searchControls.setTimeLimit(searchTimeLimit);
      
      return dctx.search(departmentBaseDN, filter, searchControls);
   }
   
   private LDAPDepartment createLdapDepartment(final SearchResult result)
         throws NamingException
   {
      final Attributes attributes = result.getAttributes();
      
      final String name = (String) attributes.get(departmentNameAttribute).get();
      final String description = (String) attributes.get(departmentDescriptionAttribute).get();
      
      return (name != null) ? new LDAPDepartment(name, description) : null;
   }
   
   /**
    * @param LDAPPerson
    *           the ldap representation of the user whose roles have to be searched.
    * @return an iterator containing the result (participant IDs)
    */
   public Collection getParticipants(LDAPPerson person)
   {
      List result = new ArrayList();

      String filter = StringUtils.replace(Parameters.instance().getString(
            LDAPProperties.PARTICIPANT_FILTER_PROPERTY), "%v", person.getRdn());

      trace.debug("Using filter: '" + filter + "'.");

      try
      {
         DirContext dctx = connection.getContext();

         SearchControls searchControls = new SearchControls();
         searchControls.setSearchScope(groupQueryScope);
         searchControls.setTimeLimit(searchTimeLimit);

         NamingEnumeration<SearchResult> searchResult = dctx
               .search(groupBaseDN, filter, searchControls);

         while (searchResult.hasMore())
         {
            result.add(searchResult.next().getAttributes().get(
                  participantIDAttribute).get());
         }
      }
      catch (Exception e)
      {
         trace.warn("", e);
      }
      return result;
   }
   
   public Set<GrantInfo> getModelParticipantsGrants(final LDAPPerson person)
   {
      final Set<GrantInfo> grants = CollectionUtils.newHashSet();
      final String filter = StringUtils.replace(Parameters.instance().getString(
            LDAPProperties.PARTICIPANT_FILTER_PROPERTY), "%v", person.getRdn());
      trace.debug("Using filter: '" + filter + "'.");

      try
      {
         final DirContext dctx = connection.getContext();

         final SearchControls searchControls = new SearchControls();
         searchControls.setSearchScope(groupQueryScope);
         searchControls.setTimeLimit(searchTimeLimit);

         final NamingEnumeration<SearchResult> searchResult = dctx
               .search(groupBaseDN, filter, searchControls);

         while (searchResult.hasMore())
         {
            final String cn = (String) searchResult.next().getAttributes()
                                          .get(participantIDAttribute).get();
            grants.add(extractGrantInfo(cn));
         }
      }
      catch (Exception e)
      {
         trace.warn("Failed to get user's grants.", e);
      }
      
      return grants;
   }
   
   private GrantInfo extractGrantInfo(final String cn)
   {
      final int firstIndexOfOrgDeptDelim = cn.indexOf(ORG_DEPT_DELIM_LEFT);
      if (firstIndexOfOrgDeptDelim == -1)
      {
         return new GrantInfo(cn, Collections.<String>emptyList());
      }
      else
      {
         final String participantId = cn.substring(0, firstIndexOfOrgDeptDelim);
         final String deptString = cn.substring(firstIndexOfOrgDeptDelim + 1, cn.length() - 1);
         
         final List<String> deptKey = CollectionUtils.newArrayList();
         final String[] deptKeyStr = deptString.split(DEPT_DELIM);
         for (final String s : deptKeyStr)
         {
            deptKey.add(s);
         }
         
         return new GrantInfo(participantId, deptKey);
      }
   }
}
