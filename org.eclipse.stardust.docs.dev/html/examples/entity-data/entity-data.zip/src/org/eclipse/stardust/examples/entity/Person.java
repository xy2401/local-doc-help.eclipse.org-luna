/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
package org.eclipse.stardust.examples.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.GeneratedValue;
import javax.persistence.SequenceGenerator;
import javax.persistence.GenerationType;

@Entity
@SequenceGenerator(name="person_seq", initialValue=1, allocationSize=50)
public class Person  {
   @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="person_seq")
   @Id
   private Long id;
   private String name;
   private String vorname;
   
   public Long getId() {
      return id;
   }
   public void setId(Long id) {
      this.id = id;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getVorname() {
      return vorname;
   }
   public void setVorname(String vorname) {
      this.vorname = vorname;
   }
   
   public String toString() {
   StringBuilder sb = new StringBuilder();
   sb.append(">>> Person id: ").append(id).append(" | vorname: ").append(vorname);
   sb.append(" | name: ").append(name).append(" | hashCode: ").append(hashCode());
   return sb.toString();
   }
}