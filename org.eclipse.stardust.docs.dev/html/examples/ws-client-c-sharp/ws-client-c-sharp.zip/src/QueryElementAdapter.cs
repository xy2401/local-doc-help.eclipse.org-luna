﻿using System;
using System.Xml;
using System.Xml.Serialization;

namespace com.infinity.bpm.api.query.stubs
{
    public partial class OrderCriteria : object, System.Xml.Serialization.IXmlSerializable
    {
        public com.infinity.bpm.api.query.OrderCriteria QueryOrderCriteria
        {
            set { nodesField = QueryElement2XmlNode.ToXmlNodes(value); }
        }
    }

    public partial class Policy : object, System.Runtime.Serialization.IExtensibleDataObject
    {
        public com.infinity.bpm.api.query.Policy QueryPolicy
        {
            set
            {
                // TODO look for a smarter way to map objects
                this.descriptorPolicy = GetDescriptorPolicy(value.descriptorPolicy);
                this.historicalEventPolicy = GetHistoricalEventPolicy(value.historicalEventPolicy);
                this.historicalStatesPolicy = GetHistoricalStatesPolicy(value.historicalStatesPolicy);
                this.modelVersionPolicy = GetModelVersionPolicy(value.modelVersionPolicy);
                this.processInstanceDetailsPolicy = GetProcessInstanceDetailsPolicy(value.processInstanceDetailsPolicy);
                this.subsetPolicy = GetSubsetPolicy(value.subsetPolicy);
                this.criticalCostPerExecutionPolicy = GetCriticalCostPerExecutionPolicy(value.criticalCostPerExecutionPolicy);
                this.criticalExecutionTimePolicy = GetCriticalExecutionTimePolicy(value.criticalExecutionTimePolicy);
                this.criticalProcessingTimePolicy = GetCriticalProcessingTimePolicy(value.criticalProcessingTimePolicy);
                this.performanceCriticalityPolicy = GetPerformanceCriticalityPolicy(value.performanceCriticalityPolicy);
                this.processCumulationPolicy = GetProcessCumulationPolicy(value.processCumulationPolicy);
                this.timeoutPolicy = GetTimeoutPolicy(value.timeoutPolicy);
                this.userDetailsPolicy = GetUserDetailsPolicy(value.userDetailsPolicy);
            }
        }

        private DescriptorPolicy GetDescriptorPolicy(com.infinity.bpm.api.query.DescriptorPolicy policy)
        {
            if (policy == null) return null;

            DescriptorPolicy descriptorPolicy = new DescriptorPolicy();
            descriptorPolicy.Nodes = QueryElement2XmlNode.ToXmlNodes(policy);
            return descriptorPolicy;
        }

        private HistoricalEventPolicy GetHistoricalEventPolicy(com.infinity.bpm.api.query.HistoricalEventPolicy policy)
        {
            if (policy == null) return null;

            HistoricalEventPolicy historicalEventPolicy = new HistoricalEventPolicy();
            historicalEventPolicy.eventTypes = new HistoricalEventTypes();
            historicalEventPolicy.eventTypes.Nodes = QueryElement2XmlNode.ToXmlNodes(policy);
            return historicalEventPolicy;
        }

        private HistoricalStatesPolicy GetHistoricalStatesPolicy(com.infinity.bpm.api.query.HistoricalStatesPolicy policy)
        {
            if (policy == null) return null;

            HistoricalStatesPolicy historicalStatesPolicy = new HistoricalStatesPolicy();
            historicalStatesPolicy.Nodes = QueryElement2XmlNode.ToXmlNodes(policy);
            return historicalStatesPolicy;
        }

        private ModelVersionPolicy GetModelVersionPolicy(com.infinity.bpm.api.query.ModelVersionPolicy policy)
        {
            if (policy == null) return null;

            ModelVersionPolicy modelVersionPolicy = new ModelVersionPolicy();
            modelVersionPolicy.Nodes = QueryElement2XmlNode.ToXmlNodes(policy);
            return modelVersionPolicy;
        }

        private ProcessInstanceDetailsPolicy GetProcessInstanceDetailsPolicy(com.infinity.bpm.api.query.ProcessInstanceDetailsPolicy policy)
        {
            if (policy == null) return null;

            ProcessInstanceDetailsPolicy processInstanceDetailsPolicy = new ProcessInstanceDetailsPolicy();
            switch (policy.detailsLevel)
            {
                case com.infinity.bpm.api.query.ProcessInstanceDetailsLevel.Core:
                    processInstanceDetailsPolicy.detailsLevel = ProcessInstanceDetailsLevel.Core;
                    break;
                case com.infinity.bpm.api.query.ProcessInstanceDetailsLevel.Default:
                    processInstanceDetailsPolicy.detailsLevel = ProcessInstanceDetailsLevel.Default;
                    break;
                case com.infinity.bpm.api.query.ProcessInstanceDetailsLevel.Full:
                    processInstanceDetailsPolicy.detailsLevel = ProcessInstanceDetailsLevel.Full;
                    break;
                case com.infinity.bpm.api.query.ProcessInstanceDetailsLevel.WithProperties:
                    processInstanceDetailsPolicy.detailsLevel = ProcessInstanceDetailsLevel.WithProperties;
                    break;
                case com.infinity.bpm.api.query.ProcessInstanceDetailsLevel.WithResolvedProperties:
                    processInstanceDetailsPolicy.detailsLevel = ProcessInstanceDetailsLevel.WithResolvedProperties;
                    break;
                default:
                    throw new NotSupportedException("Unsupported Process Instance Details Level: " + policy.detailsLevel + ".");
            }
            return processInstanceDetailsPolicy;
        }

        private SubsetPolicy GetSubsetPolicy(com.infinity.bpm.api.query.SubsetPolicy policy)
        {
            if (policy == null) return null;

            SubsetPolicy subsetPolicy = new SubsetPolicy();
            subsetPolicy.evaluateTotalCount = policy.evaluateTotalCount;
            subsetPolicy.maxSize = policy.maxSize;
            subsetPolicy.skippedEntries = policy.skippedEntries;
            return subsetPolicy;
        }

        private CriticalCostPerExecutionPolicy GetCriticalCostPerExecutionPolicy(com.infinity.bpm.api.query.CriticalCostPerExecutionPolicy policy)
        {
            if (policy == null) return null;

            CriticalCostPerExecutionPolicy criticalCostPerExecutionPolicy = new CriticalCostPerExecutionPolicy();
            criticalCostPerExecutionPolicy.Nodes = QueryElement2XmlNode.ToXmlNodes(policy);
            return criticalCostPerExecutionPolicy;
        }

        private CriticalExecutionTimePolicy GetCriticalExecutionTimePolicy(com.infinity.bpm.api.query.CriticalExecutionTimePolicy policy)
        {
            if (policy == null) return null;

            CriticalExecutionTimePolicy criticalExecutionTimePolicy = new CriticalExecutionTimePolicy();
            criticalExecutionTimePolicy.Nodes = QueryElement2XmlNode.ToXmlNodes(policy);
            return criticalExecutionTimePolicy;
        }

        private CriticalProcessingTimePolicy GetCriticalProcessingTimePolicy(com.infinity.bpm.api.query.CriticalProcessingTimePolicy policy)
        {
            if (policy == null) return null;

            CriticalProcessingTimePolicy criticalProcessingTimePolicy = new CriticalProcessingTimePolicy();
            criticalProcessingTimePolicy.Nodes = QueryElement2XmlNode.ToXmlNodes(policy);
            return criticalProcessingTimePolicy;
        }

        private PerformanceCriticalityPolicy GetPerformanceCriticalityPolicy(com.infinity.bpm.api.query.PerformanceCriticalityPolicy policy)
        {
            if (policy == null) return null;

            PerformanceCriticalityPolicy performanceCriticalityPolicy = new PerformanceCriticalityPolicy();
            performanceCriticalityPolicy.lowPriorityCriticalPct = policy.lowPriorityCriticalPct;
            performanceCriticalityPolicy.normalPriorityCriticalPct = policy.normalPriorityCriticalPct;
            performanceCriticalityPolicy.highPriorityCriticalPct = policy.highPriorityCriticalPct;
            return performanceCriticalityPolicy;
        }

        private TimeoutPolicy GetTimeoutPolicy(com.infinity.bpm.api.query.TimeoutPolicy policy)
        {
            if (policy == null) return null;

            TimeoutPolicy timeoutPolicy = new TimeoutPolicy();
            timeoutPolicy.timeout = policy.timeout;
            return timeoutPolicy;
        }

        private ProcessCumulationPolicy GetProcessCumulationPolicy(com.infinity.bpm.api.query.ProcessCumulationPolicy policy)
        {
            if (policy == null) return null;

            ProcessCumulationPolicy processCumulationPolicy = new ProcessCumulationPolicy();
            processCumulationPolicy.cumulateWithRootPi = policy.cumulateWithRootPi;
            processCumulationPolicy.cumulateWithScopePi = policy.cumulateWithScopePi;
            return processCumulationPolicy;
        }

        private UserDetailsPolicy GetUserDetailsPolicy(com.infinity.bpm.api.query.UserDetailsPolicy policy)
        {
            if (policy == null) return null;

            UserDetailsPolicy userDetailsPolicy = new UserDetailsPolicy();
            switch (policy.level)
            {
                case com.infinity.bpm.api.query.UserDetailsLevel.Core:
                    userDetailsPolicy.level = UserDetailsLevel.Core;
                    break;
                case com.infinity.bpm.api.query.UserDetailsLevel.Full:
                    userDetailsPolicy.level = UserDetailsLevel.Full;
                    break;
                case com.infinity.bpm.api.query.UserDetailsLevel.WithProperties:
                    userDetailsPolicy.level = UserDetailsLevel.WithProperties;
                    break;
                default:
                    throw new NotSupportedException("Unsupported User Details Level: " + policy.level + ".");
            }
            return userDetailsPolicy;
        }
    }

    public partial class AndTerm : object, System.Xml.Serialization.IXmlSerializable
    {
        public com.infinity.bpm.api.query.AndTerm QueryAndTerm
        {
            set { nodesField = QueryElement2XmlNode.ToXmlNodes(value); }
        }
    }

    internal class QueryElement2XmlNode
    {
        internal static XmlNode[] ToXmlNodes<T>(T t)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlWriter xmlWriter = xmlDoc.CreateNavigator().AppendChild();
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
            xmlSerializer.Serialize(xmlWriter, t);
            xmlWriter.Flush();
            xmlWriter.Close();

            int xmlNodesCount = xmlDoc.DocumentElement.ChildNodes.Count;
            XmlNode[] xmlNodes = new XmlNode[xmlNodesCount];
            for (int i = 0; i < xmlNodesCount; i++)
            {
                xmlNodes[i] = xmlDoc.DocumentElement.ChildNodes[i];
            }

            return xmlNodes;
        }
    }
}