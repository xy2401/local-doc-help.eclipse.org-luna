/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;

import java.util.Collections;
import java.util.Map;

import org.eclipse.stardust.engine.core.spi.security.ExternalUserGroupConfiguration;


public class UserGroupConfiguration extends ExternalUserGroupConfiguration
{
   private final PropertyRegistry registry;
   private final String id;

   public UserGroupConfiguration(PropertyRegistry registry, String id)
   {
      this.registry = registry;
      this.id = id;
   }

   public String getName()
   {
      return registry.getGroupName(id);
   }

   public String getDescription()
   {
      return null;
   }

   public Map getProperties()
   {
      return Collections.EMPTY_MAP;
   }
}
