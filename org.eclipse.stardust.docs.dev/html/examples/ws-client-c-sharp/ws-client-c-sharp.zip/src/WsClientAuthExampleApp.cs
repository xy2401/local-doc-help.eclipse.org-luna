﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using com.infinity.bpm.api;
using com.infinity.bpm.api.query.stubs;

namespace InfinityWsClient
{
    class InfinityServiceAuthTestApp
    {
        private const String MOTU_USERNAME = "motu";
        private const String MOTU_PWD = "motu";
        private static readonly Dictionary<String, String> SESSION_PROPERTIES;

        static InfinityServiceAuthTestApp()
        {
            SESSION_PROPERTIES = new Dictionary<String, String>();
            SESSION_PROPERTIES.Add(WsFactory.SESSION_PROP_PARTITION, "default");
            SESSION_PROPERTIES.Add(WsFactory.SESSION_PROP_REALM, "carnot");
            SESSION_PROPERTIES.Add(WsFactory.SESSION_PROP_DOMAIN, "default");
        }

        static void Main(String[] args)
        {
            doWfServiceCallHttpBasicAuth();
            doWfServiceCallHttpBasicAuthSsl();
            doWfServiceCallWssUsernameToken();

            doQueryServiceCallHttpBasicAuth();
            doQueryServiceCallHttpBasicAuthSsl();
            doQueryServiceCallWssUsernameToken();

            doDocMgmtServiceCallHttpBasicAuth();
            doDocMgmtServiceCallHttpBasicAuthSsl();
            doDocMgmtServiceCallWssUsernameToken();

            doUserServiceCallHttpBasicAuth();
            doUserServiceCallHttpBasicAuthSsl();
            doUserServiceCallWssUsernameToken();

            doAdminServiceCallHttpBasicAuth();
            doAdminServiceCallHttpBasicAuthSsl();
            doAdminServiceCallWssUsernameToken();
        }

        private static void doWfServiceCallHttpBasicAuth()
        {
            Console.Write(WsFactory.WF_SERVICE_HTTP_BASIC_AUTH + ": ");

            IWorkflowService wfService = WsFactory.GetWorkflowService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);

            User user = wfService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doWfServiceCallHttpBasicAuthSsl()
        {
            Console.Write(WsFactory.WF_SERVICE_HTTP_BASIC_AUTH_SSL + ": ");

            IWorkflowService wfService = WsFactory.GetWorkflowService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthenticationSsl);

            User user = wfService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doWfServiceCallWssUsernameToken()
        {
            Console.Write(WsFactory.WF_SERVICE_WSS_USERNAME_TOKEN + ": ");

            IWorkflowService wfService = WsFactory.GetWorkflowService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.WssUsernameToken);

            User user = wfService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doQueryServiceCallHttpBasicAuth()
        {
            Console.Write("\n" + WsFactory.QUERY_SERVICE_HTTP_BASIC_AUTH + ": ");

            IQueryService queryService = WsFactory.GetQueryService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);

            Permissions permissions = queryService.getPermissions();
            Console.WriteLine(permissions.Count + " permissions found!");
        }

        private static void doQueryServiceCallHttpBasicAuthSsl()
        {
            Console.Write("\n" + WsFactory.QUERY_SERVICE_HTTP_BASIC_AUTH_SSL + ": ");

            IQueryService queryService = WsFactory.GetQueryService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthenticationSsl);

            Permissions permissions = queryService.getPermissions();
            Console.WriteLine(permissions.Count + " permissions found!");
        }

        private static void doQueryServiceCallWssUsernameToken()
        {
            Console.Write(WsFactory.QUERY_SERVICE_WSS_USERNAME_TOKEN + ": ");

            IQueryService queryService = WsFactory.GetQueryService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.WssUsernameToken);

            Permissions permissions = queryService.getPermissions();
            Console.WriteLine(permissions.Count + " permissions found!");
        }

        private static void doDocMgmtServiceCallHttpBasicAuth()
        {
            Console.Write("\n" + WsFactory.DOC_MGMT_SERVICE_HTTP_BASIC_AUTH + ": ");

            IDocumentManagementService docMgmtService = WsFactory.GetDocMgmtService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);

            String folderName = "Test";
            FolderInfo folderInfo = new FolderInfo();
            folderInfo.name = folderName;
            Folder folder = docMgmtService.createFolder("/", folderInfo);
            Console.Write("Folder '" + folderName + "' created ... ");
            docMgmtService.removeFolder(folder.id, false);
            Console.WriteLine("and deleted.");
        }

        private static void doDocMgmtServiceCallHttpBasicAuthSsl()
        {
            Console.Write("\n" + WsFactory.DOC_MGMT_SERVICE_HTTP_BASIC_AUTH_SSL + ": ");

            IDocumentManagementService docMgmtService = WsFactory.GetDocMgmtService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthenticationSsl);

            String folderName = "Test";
            FolderInfo folderInfo = new FolderInfo();
            folderInfo.name = folderName;
            Folder folder = docMgmtService.createFolder("/", folderInfo);
            Console.Write("Folder '" + folderName + "' created ... ");
            docMgmtService.removeFolder(folder.id, false);
            Console.WriteLine("and deleted.");
        }

        private static void doDocMgmtServiceCallWssUsernameToken()
        {
            Console.Write(WsFactory.DOC_MGMT_WSS_USERNAME_TOKEN + ": ");

            IDocumentManagementService docMgmtService = WsFactory.GetDocMgmtService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.WssUsernameToken);

            String folderName = "Test";
            FolderInfo folderInfo = new FolderInfo();
            folderInfo.name = folderName;
            Folder folder = docMgmtService.createFolder("/", folderInfo);
            Console.Write("Folder '" + folderName + "' created ... ");
            docMgmtService.removeFolder(folder.id, false);
            Console.WriteLine("and deleted.");
        }

        private static void doUserServiceCallHttpBasicAuth()
        {
            Console.Write("\n" + WsFactory.USER_SERVICE_HTTP_BASIC_AUTH + ": ");

            IUserService userService = WsFactory.GetUserService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);

            User user = userService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doUserServiceCallHttpBasicAuthSsl()
        {
            Console.Write("\n" + WsFactory.USER_SERVICE_HTTP_BASIC_AUTH_SSL + ": ");

            IUserService userService = WsFactory.GetUserService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthenticationSsl);

            User user = userService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doUserServiceCallWssUsernameToken()
        {
            Console.Write(WsFactory.USER_SERVICE_WSS_USERNAME_TOKEN + ": ");

            IUserService userService = WsFactory.GetUserService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.WssUsernameToken);

            User user = userService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doAdminServiceCallHttpBasicAuth()
        {
            Console.Write("\n" + WsFactory.ADMIN_SERVICE_HTTP_BASIC_AUTH + ": ");

            IAdministrationService adminService = WsFactory.GetAdminService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);

            
            User user = adminService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doAdminServiceCallHttpBasicAuthSsl()
        {
            Console.Write("\n" + WsFactory.ADMIN_SERVICE_HTTP_BASIC_AUTH_SSL + ": ");

            IAdministrationService adminService = WsFactory.GetAdminService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthenticationSsl);


            User user = adminService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }

        private static void doAdminServiceCallWssUsernameToken()
        {
            Console.Write(WsFactory.ADMIN_SERVICE_WSS_USERNAME_TOKEN + ": ");

            IAdministrationService adminService = WsFactory.GetAdminService(MOTU_USERNAME, MOTU_PWD,
                SESSION_PROPERTIES, WsFactory.AuthenticationMode.HttpBasicAuthentication);

            User user = adminService.getSessionUser();
            Console.WriteLine(user.firstName + " " + user.lastName);
        }
    }
}
