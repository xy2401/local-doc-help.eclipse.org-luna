/*******************************************************************************
 * Copyright (c) 2000, 2011 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/


package org.eclipse.stardust.examples.supportcase;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

/**
 * Initializes Support Case Data
 */
public class SupportCase
{
	public static Map<String, Object> createSupportData() throws ParseException
	{
		Map<String, String> initProduct = new HashMap<String, String>();
		initProduct.put("Name", "");
		initProduct.put("Analysis", "");
		initProduct.put("Synopsis", "");
		initProduct.put("State", "O");
	
		Map<String, Object> initCustomer = new HashMap<String, Object>();
		initCustomer.put("Name","");
		initCustomer.put("Id","");
		initCustomer.put("Email","");
		initCustomer.put("Product",initProduct);
	
		return initCustomer;
	}			
}


