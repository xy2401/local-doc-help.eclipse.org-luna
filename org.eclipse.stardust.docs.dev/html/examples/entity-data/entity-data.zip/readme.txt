********************************************

Entity Data Type Usage Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The Entity Data type usage example provides bean classes and an example model using
these classes to set up entity bean data and the required session bean applications. 

Please refer to chapter "How to use the Entity Data Type" in the documentation
for a guidance how to use the Entity Data type in our product.
