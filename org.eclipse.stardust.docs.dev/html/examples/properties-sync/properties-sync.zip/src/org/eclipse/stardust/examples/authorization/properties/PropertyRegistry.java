/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;

import java.io.*;
import java.util.*;

import org.eclipse.stardust.common.StringUtils;
import org.eclipse.stardust.common.config.Parameters;
import org.eclipse.stardust.common.error.InternalException;
import org.eclipse.stardust.engine.core.spi.security.ExternalUserConfiguration.GrantInfo;


/**
 * @author ubirkemeyer
 * @version $Revision$
 */
public class PropertyRegistry
{
   private Properties properties = new Properties();

   private static final String REGISTRY_FILE = "User.Registry";
   private static final String DEFAULT_REGISTRY_FILE = "user-registry.properties";

   private static final String PREFIX_USER = "User.";
   private static final String PREFIX_GROUP = "Group.";
   private static final String PREFIX_DEPARTMENT = "Department.";

   private static final String PARAM_PASSWORD = ".Password";
   private static final String PARAM_FIRST_NAME = ".FirstName";
   private static final String PARAM_LAST_NAME = ".LastName";
   private static final String PARAM_EMAIL = ".EMail";
   private static final String PARAM_ROLES = ".Roles";
   private static final String PARAM_GROUPS = ".UserGroups";
   private static final String PARAM_NAME = ".Name";
   private static final String PARAM_DESCRIPTION = ".Description";

   public boolean containsUser(String account)
   {
      return properties.containsKey(PREFIX_USER + account + PARAM_PASSWORD);
   }

   public void createUser(String account, String password)
   {
      deleteUser(account);
      properties.put(PREFIX_USER + account + PARAM_PASSWORD, password);
   }

   public String getPassword(String account)
   {
      return properties.getProperty(PREFIX_USER + account + PARAM_PASSWORD);
   }

   public void deleteUser(String account)
   {
      properties.remove(PREFIX_USER + account + PARAM_PASSWORD);
      properties.remove(PREFIX_USER + account + PARAM_FIRST_NAME);
      properties.remove(PREFIX_USER + account + PARAM_LAST_NAME);
      properties.remove(PREFIX_USER + account + PARAM_EMAIL);
      properties.remove(PREFIX_USER + account + PARAM_ROLES);
      properties.remove(PREFIX_USER + account + PARAM_GROUPS);
   }

   public String getFirstNameForUser(String account)
   {
      return properties.getProperty(PREFIX_USER + account + PARAM_FIRST_NAME);
   }

   public String getLastNameForUser(String account)
   {
      return properties.getProperty(PREFIX_USER + account + PARAM_LAST_NAME);
   }

   public String getEMailForUser(String account)
   {
      return properties.getProperty(PREFIX_USER + account + PARAM_EMAIL);
   }

   public Set getAllRolesForUser(String account)
   {
      return getRoles(properties.getProperty(PREFIX_USER + account + PARAM_ROLES));
   }

   public Set<GrantInfo> getModelParticipantsGrants(final String account)
   {
      final String grantsString = properties.getProperty(PREFIX_USER + account + PARAM_ROLES);
      return getGrants(grantsString);
   }
   
   public void addRole(String account, String role)
   {
      Set roles = getAllRolesForUser(account);
      roles.add(role);
      String value = convertToRoleString(roles);
      properties.put(PREFIX_USER + account + PARAM_ROLES, value);
   }

   public void removeRole(String account, String role)
   {
      Set roles = getAllRolesForUser(account);
      roles.remove(role);
      String value = convertToRoleString(roles);
      properties.put(PREFIX_USER + account + PARAM_ROLES, value);
   }

   public Set getAllGroupsForUser(String account)
   {
      return getRoles(properties.getProperty(PREFIX_USER + account + PARAM_GROUPS));
   }

   public boolean containsUserGroup(String id)
   {
      return properties.containsKey(PREFIX_GROUP + id + PARAM_NAME);
   }

   public String getGroupName(String id)
   {
      return properties.getProperty(PREFIX_GROUP + id + PARAM_NAME);
   }

   public boolean containsDepartment(final String departmentKey)
   {
      return properties.containsKey(PREFIX_DEPARTMENT + departmentKey
            + PARAM_NAME);
   }

   public String getNameForDepartment(final String departmentId)
   {
      return properties.getProperty(PREFIX_DEPARTMENT + departmentId + PARAM_NAME);
   }
   
   public String getDescriptionForDepartment(final String departmentId)
   {
      return properties.getProperty(PREFIX_DEPARTMENT + departmentId + PARAM_DESCRIPTION);
   }

   public void load()
   {
      String registryFile = Parameters.instance().getString(REGISTRY_FILE,
            DEFAULT_REGISTRY_FILE);
      try
      {
         InputStream inStream = new FileInputStream(registryFile);
         properties.load(inStream);
         inStream.close();
      }
      catch (IOException e)
      {
         throw new InternalException(e);
      }
   }

   public void save()
   {
      String registryFile = Parameters.instance().getString(REGISTRY_FILE,
            DEFAULT_REGISTRY_FILE);
      try
      {
         OutputStream outStream = new FileOutputStream(registryFile);
         properties.store(outStream, "xxx");
         outStream.close();
      }
      catch (IOException e)
      {
         throw new InternalException(e);
      }
   }

   private Set getRoles(String roleString)
   {
      Set result = new HashSet();
      if (roleString == null)
      {
         return result;
      }
      for (StringTokenizer tkr = new StringTokenizer(roleString, ";"); tkr.hasMoreTokens();)
      {
         String s = tkr.nextToken();
         result.add(s.trim());
      }
      return result;
   }

   private Set<GrantInfo> getGrants(final String grantsString)
   {
      final Set<GrantInfo> grants = new HashSet<GrantInfo>();
      if ( !StringUtils.isEmpty(grantsString))
      {
         final String[] grantStrings = grantsString.split(";");
         for (String s : grantStrings)
         {
            try
            {
               grants.add(getGrantInfoFrom(s));
            }
            catch (Exception e)
            {
               /* ignore invalid grant */
            }
         }
      }
      
      return grants;
   }
   
   private GrantInfo getGrantInfoFrom(final String grantString)
   {
      String participantId;
      List<String> departmentKeys = new ArrayList<String>();
      final int orgPartEndIndex = grantString.indexOf("<");
      if (orgPartEndIndex != -1)
      {
         participantId = grantString.substring(0, orgPartEndIndex);
         String deptStr = grantString.substring(orgPartEndIndex + 1, grantString.length() - 1);
         final String[] departKeyStrings = deptStr.split(",");
         for (final String s : departKeyStrings)
         {
            departmentKeys.add(s);
         }
      }
      else
      {
         participantId = grantString;
      }
      return new GrantInfo(participantId, departmentKeys);
   }
   
   private String convertToRoleString(Set roles)
   {
      StringBuffer value = new StringBuffer();
      for (Iterator i = roles.iterator(); i.hasNext();)
      {
         String s = (String) i.next();
         value.append(s);
         if (i.hasNext())
         {
            value.append("; ");
         }
      }
      return value.toString();
   }
}
