********************************************

WebLogic AuthenticatedBeanFactory Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

This example contains the source code for the WeblogicAuthenticatedBeanFactory.

An AuthenticatedBeanFactory is responsible for
authenticating the user at an application server. After a successful login to
the application server it returns a session bean. There is no need to
call the login method on this session, if retrieved by an AuthenticatedBeanFactory.

Since the mechanisms to authenticate against an application server are
not portable for each application server there has to be an own AuthenticatedBeanFactory.
Even different configurations or authentication methods can require different AuthenticatedBeanFactory
classes. This is an example of how to authenticate against BEA's WebLogic Server 6.1.

For more detailed information on the AuthenticatedBeanFactory
interface please refer to chapter "Implementing Custom Security in the 
Programming Guide of the documentation.