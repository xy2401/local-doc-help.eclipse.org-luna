********************************************

Support Case Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

This example contains the example models and the source code for the support 
case tutorial.

The support case tutorial is a simple tutorial aiming and introducing you to all
major aspects of modeling and programming with our product.

It is not supposed to give you a detailed view of all the product
functionalities, but will help you getting started with the software.

A detailed description of how to work with this example and a step by step
description of how to create the support case model can be found in the Support
Case Tutorial in the Tutorial Guide of the documentation.
