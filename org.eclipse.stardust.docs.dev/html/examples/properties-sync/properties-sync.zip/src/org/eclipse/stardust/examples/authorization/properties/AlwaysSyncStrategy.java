/*******************************************************************************
 * Copyright (c) 2012, 2014�SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC�- initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id: $
 * (C) 2000-2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;

import org.eclipse.stardust.engine.core.runtime.beans.IDepartment;
import org.eclipse.stardust.engine.core.runtime.beans.IUser;
import org.eclipse.stardust.engine.core.runtime.beans.IUserGroup;
import org.eclipse.stardust.engine.core.spi.security.DynamicParticipantSynchronizationStrategy;


/**
 * @author nicolas.werlein
 * @version $Revision: $
 */
public class AlwaysSyncStrategy extends DynamicParticipantSynchronizationStrategy
{
   @Override
   public boolean isDirty(final IUser user)
   {
      return true;
   }
   
   @Override
   public boolean isDirty(final IUserGroup userGroup)
   {
      return true;
   }
   
   @Override
   public boolean isDirty(final IDepartment department)
   {
      return true;
   }
   
   @Override
   public void setSynchronized(IUser user)
   {
      /* nothing to do */
   }
}
