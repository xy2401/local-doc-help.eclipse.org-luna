/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.stardust.engine.core.spi.security.ExternalUserConfiguration;


public class UserConfiguration extends ExternalUserConfiguration
{
   private final PropertyRegistry registry;
   private final String account;

   public UserConfiguration(PropertyRegistry registry, String account)
   {
      this.registry = registry;
      this.account = account;
   }

   public String getFirstName()
   {
      return registry.getFirstNameForUser(account);
   }

   public String getLastName()
   {
      return registry.getLastNameForUser(account);
   }

   public String getEMail()
   {
      return registry.getEMailForUser(account);
   }

   public String getDescription()
   {
      return null;
   }

   public Map getProperties()
   {
      return new HashMap();
   }

   public Collection getGrantedModelParticipants()
   {
      return registry.getAllRolesForUser(account);
   }

   public Collection getUserGroupMemberships()
   {
      return registry.getAllGroupsForUser(account);
   }

   @Override
   public Set<GrantInfo> getModelParticipantsGrants()
   {
      return registry.getModelParticipantsGrants(account);
   }
}
