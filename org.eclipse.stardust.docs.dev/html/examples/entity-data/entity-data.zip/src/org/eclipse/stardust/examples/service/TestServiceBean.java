/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
package org.eclipse.stardust.examples.service;

import javax.ejb.Remote;
import javax.ejb.Stateful;

import org.eclipse.stardust.examples.entity.Person;

@Remote(TestService.class)
@Stateful(mappedName = "ejb/TestService")
public class TestServiceBean implements TestService {

   @Override
   public Person createPersonEntity() {

      Person p = new Person();

      p.setVorname("Bart");
      p.setName("Simpson");

      return p;
   }

   @Override
   public Person changePerson(Person p) {

      System.out.println("Original: " + p);

      p.setVorname("Changed-Bart");
      p.setName("Changed-Simpson");
      System.out.println("Changed: " + p);
      
      return p;
   }
}