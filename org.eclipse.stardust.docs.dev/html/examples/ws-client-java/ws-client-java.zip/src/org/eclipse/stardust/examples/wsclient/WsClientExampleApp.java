/*******************************************************************************
 * Copyright (c) 2000, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/

package org.eclipse.stardust.examples.wsclient;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import javax.activation.DataHandler;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.eclipse.stardust.common.CollectionUtils;
import org.eclipse.stardust.common.log.LogManager;
import org.eclipse.stardust.common.log.Logger;
import org.eclipse.stardust.engine.api.runtime.DmsUtils;
import org.eclipse.stardust.engine.api.runtime.DocumentInfo;
import org.eclipse.stardust.engine.core.runtime.beans.removethis.SecurityProperties;
import org.w3c.dom.Element;


import org.eclipse.stardust.engine.api.ws.*;
import org.eclipse.stardust.engine.api.ws.GetProcessProperties.PropertyIdsXto;
import org.eclipse.stardust.engine.api.ws.GrantsXto.GrantXto;
import org.eclipse.stardust.engine.api.ws.query.ActivityQueryXto;
import org.eclipse.stardust.engine.api.ws.query.ProcessQueryXto;
import org.eclipse.stardust.engine.ws.DocumentContentDataSource;
import org.eclipse.stardust.examples.wsclient.WsFactory.AuthMode;

/**
 * <p>
 * This sample demonstrates running a tiny process using our WS API. It depends on the
 * process model <code>WsClientExampleModel.xpdl</code> and comprises the following
 * steps
 * <ul>
 * <li>Starting a process with a process attachment</li>
 * <li>Accessing the process attachment</li>
 * <li>Querying for process instances</li>
 * <li>Querying for activity instances</li>
 * <li>Adding a grant to the session user</li>
 * <li>Completing the activity which finishes the process</li>
 * </ul>
 * </p>
 * 
 * @author nicolas.werlein
 * @version $Revision: $
 */
public class WsClientExampleApp
{
   private static final Logger LOGGER = LogManager.getLogger(WsClientExampleApp.class);

   private static final String MOTU_USERNAME = "motu";

   private static final String MOTU_PWD = "motu";

   private static final Map<String, String> SESSION_PROPERTIES;

   private static final String PROCESS_DEFINITION_NAME = "ProcessDefinition";

   private static final String PROCESS_ATTACHMENTS_ID = "PROCESS_ATTACHMENTS";

   private static final String ROLE_ID = "Role";

   private static final IWorkflowService WF_SERVICE;

   private static final IQueryService QUERY_SERVICE;

   private static final IUserService USER_SERVICE;

   static
   {
      SESSION_PROPERTIES = initSessionProperties();

      WF_SERVICE = WsFactory.getWorkflowService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.HTTP_BASIC_AUTH);
      QUERY_SERVICE = WsFactory.getQueryService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.HTTP_BASIC_AUTH);
      USER_SERVICE = WsFactory.getUserService(MOTU_USERNAME, MOTU_PWD,
            SESSION_PROPERTIES, AuthMode.HTTP_BASIC_AUTH);
   }

   public static void main(String[] args) throws BpmFault
   {
      final ProcessInstanceXto pi = startProcess();
      accessProcessAttachment(pi);
      doPiQuery();
      doAiQuery();
      addGrantToSessionUser();
      completeAI(pi);
   }

   private static ProcessInstanceXto startProcess() throws BpmFault
   {
      LOGGER.info("-- Starting Process --");
      final InputDocumentsXto processAttachments = createProcessAttachments();
      final ProcessInstanceXto pi = WF_SERVICE.startProcess(PROCESS_DEFINITION_NAME, null,
            true, processAttachments);
      LOGGER.info("Process '" + PROCESS_DEFINITION_NAME
            + "' started with Process Instance OID " + pi.getOid() + ".");
      return pi;
   }

   private static void accessProcessAttachment(final ProcessInstanceXto pi)
         throws BpmFault
   {
      LOGGER.info("-- Accessing the process attachment --");
      final PropertyIdsXto propertyIds = new PropertyIdsXto();
      propertyIds.getPropertyId().add(PROCESS_ATTACHMENTS_ID);
      final InstancePropertiesXto properties = WF_SERVICE.getProcessProperties(
            pi.getOid(), propertyIds);
      final List<ParameterXto> parameters = properties.getInstanceProperty();
      for (final ParameterXto p : parameters)
      {
         if (PROCESS_ATTACHMENTS_ID.equals(p.getName()))
         {
            LOGGER.info("Process Attachment:\n" + createXmlElementString(p.getXml().getAny()));
         }
      }
   }

   private static void doPiQuery() throws BpmFault
   {
      LOGGER.info("-- Querying for process instances --");
      final ProcessInstanceQueryResultXto piqr = QUERY_SERVICE.findProcesses(new ProcessQueryXto());
      final List<ProcessInstanceXto> pis = piqr.getProcessInstances()
            .getProcessInstance();
      for (final ProcessInstanceXto p : pis)
      {
         LOGGER.info("Process Instance with OID " + p.getOid() + " found, state is "
               + p.getState() + ".");
      }
   }

   private static void doAiQuery() throws BpmFault
   {
      LOGGER.info("-- Querying for activity instances --");
      final ActivityQueryResultXto aiqr = QUERY_SERVICE.findActivities(new ActivityQueryXto());
      final List<ActivityInstanceXto> ais = aiqr.getActivityInstances()
            .getActivityInstance();
      for (final ActivityInstanceXto a : ais)
      {
         LOGGER.info("Activity Instance with OID " + a.getOid() + " found, state is "
               + a.getState() + ".");
      }
   }

   private static void addGrantToSessionUser() throws BpmFault
   {
      LOGGER.info("-- Adding a grant to the session user --");
      final UserXto user = WF_SERVICE.getSessionUser();
      final GrantXto grant = new GrantXto();
      grant.setId(ROLE_ID);
      user.getGrants().getGrant().add(grant);
      USER_SERVICE.modifyUser(user, null);
   }

   private static void completeAI(final ProcessInstanceXto pi) throws BpmFault
   {
      LOGGER.info("-- Completing the activity which finishes the process --");
      ActivityInstanceXto ai = WF_SERVICE.activateNextActivityForProcess(pi.getOid());
      ai = WF_SERVICE.completeActivity(ai.getOid(), null, null, false);
      LOGGER.info("State of Activity Instance with OID " + ai.getOid()
            + " after Completion: " + ai.getState());
   }

   private static InputDocumentsXto createProcessAttachments()
   {
      final InputDocumentsXto inputDocs = new InputDocumentsXto();
      final InputDocumentXto inputDoc = new InputDocumentXto();
      inputDoc.setContent(createContent());
      inputDoc.setDocumentInfo(createDocInfo());
      inputDoc.setTargetFolder("/Test-" + System.currentTimeMillis());
      inputDocs.getInputDocument().add(inputDoc);
      return inputDocs;
   }

   private static DataHandler createContent()
   {
      final DocumentInfo docInfo = DmsUtils.createDocumentInfo("anonymous");
      return new DataHandler(new DocumentContentDataSource(docInfo,
            "This is a sample document.".getBytes()));
   }

   private static DocumentInfoXto createDocInfo()
   {
      final DocumentInfoXto docInfo = new DocumentInfoXto();
      docInfo.setName("SampleDoc.txt");
      docInfo.setDescription("This is a sample document.");
      docInfo.setContentType("text/plain");
      return docInfo;
   }
   
   private static String createXmlElementString(final List<Element> elements)
   {
      final StringWriter buffer = new StringWriter();
      
      try
      {
         final Transformer transformer = TransformerFactory.newInstance().newTransformer();
         transformer.setOutputProperty(OutputKeys.INDENT, "yes");
         for (final Element e : elements)
         {
            transformer.transform(new DOMSource(e), new StreamResult(buffer));
         }
      }
      catch (Exception e)
      {
         LOGGER.warn("Unable to create String representation for XML element" + e);
      }
      
      return buffer.toString();
   }
   
   private static Map<String, String> initSessionProperties()
   {
      final Map<String, String> sessionProperties = CollectionUtils.newHashMap();
      sessionProperties.put(SecurityProperties.PARTITION, "default");
      sessionProperties.put(SecurityProperties.REALM, "carnot");
      sessionProperties.put(SecurityProperties.DOMAIN, "default");
      return sessionProperties;
   }
}
