/*******************************************************************************
 * Copyright (c) 2011, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * _http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
package org.eclipse.stardust.examples.jfc;

import java.awt.GridLayout;
import java.util.Date;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/*
 * This will take string as input from user using JFC and will display output as simple String (not using JFC).
 * Model used - JFCSwingModel.DemoProcess
 */
public class DemoJFC extends JPanel {

	private static final long serialVersionUID = 1L;
	private PersonDetails person;
	private JTextField nameField;
	
	private JFormattedTextField dobField;
	
	private JTextField comapnyNameField = null;
	private JTextField	empIDField = null;
	private JTextArea empInfoField = null;
	
	public DemoJFC()
	{		
		super(new GridLayout(7,2));
		
		System.out.println("calling constructor");
		person = new PersonDetails();
			
		JLabel nameLabel = new JLabel("Name : ");
		
		JLabel dobLabel = new JLabel("Date of Birth : ");
		
		System.out.println("before textfield");
		nameField = new JTextField(25);
		
		dobField = new JFormattedTextField(new Date());
		
		System.out.println("after textfield");
		nameLabel.setLabelFor(nameField);
		
		dobLabel.setLabelFor(dobField);
		
		add(nameLabel);
		add(nameField);
		
		add(dobLabel);
		add(dobField);
		
		//company info
		JLabel jNameL = new JLabel("Company name : ");
	    JLabel jEmpIDL = new JLabel("Employee ID : ");
	    JLabel empInfoLabel = new JLabel("Employee info");
	    
	    comapnyNameField = new JTextField();
	    empIDField = new JTextField();
	    empInfoField = new JTextArea("Enter more personal info", 5, 5);
	    JScrollPane scrollPane = new JScrollPane(empInfoField);
	    
	    jNameL.setLabelFor(comapnyNameField);
	    jEmpIDL.setLabelFor(empIDField);
	    empInfoLabel.setLabelFor(empInfoField);
	    
	    add(jNameL);
	    add(comapnyNameField);
	    add(jEmpIDL);
	    add(empIDField);
	    add(empInfoLabel);
	    add(scrollPane);
		System.out.println("after adding fields");
	}
	
	//completion method for JFC application, saves data
	public PersonDetails save() {
		System.out.println("save called");
		person.setName(nameField.getText());
		
		person.setDob((Date)dobField.getValue());
			
		person.setCompanyName(comapnyNameField.getText());
		person.setEmpID(new Integer(empIDField.getText()));
		person.setEmpInfo(empInfoField.getText());
	
		return person;
	}

	public String getName()
	{		
		System.out.println("Inside getName");
		return person.getName();
	}
	
	public String getAddress()
	{
		System.out.println("Inside getAddress");
		return person.getCaddress(); 
	}
	
	public Date getDOB()
	{
		return person.getDob();
	}
	
	public Long getPhoneno()
	{
		return person.getPhoneno();
	}
	
	public String getCompanyName()
	{
		return person.getCompanyName();
	}
	
	public Integer getEmpID()
	{
		return person.getEmpID();
	}
	
	public String getEmpInfo()
	{
		return person.getEmpInfo();
	}
	
	public void setName(String name)
	{
		System.out.println("inside setName :  " + person.getName() + "name passed " + name);
		nameField.setText(name);
	}
	
	public void setDOB(Date date)
	{
		dobField.setText(date.toString());
	}
	
	public void setCompanyName(String companyName)
	{
		comapnyNameField.setText(companyName);
	}
	
	public void setEmpID(Integer empID)
	{
		empIDField.setText(empID.toString());
	}
	
	public void setEmpInfo(String empInfo)
	{
		empInfoField.setText(empInfo);
	}
	//completion method, does nothing for show JFC data 
	public void submit()
	{
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoJFC jfcapp = new DemoJFC();
		jfcapp.save();
	}

}
