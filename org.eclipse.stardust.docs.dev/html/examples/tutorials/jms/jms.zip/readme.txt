********************************************

JMS Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The example model provided in this section demonstrates
JMS application and JMS trigger request and response.

Tutorial

Please find the according tutorial in the Tutorial Guide of the documentation:

 * Using JMS Application and JMS Trigger - a guide how to work with JMS application and JMS trigger
